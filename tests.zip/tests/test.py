import pandas as pd
import numpy as np

#בדיקה של pd.contact 
df1 = pd.DataFrame({'A': [1, 2, 26], 'B': [3, 4, 39]})
df2 = pd.DataFrame({'A': [5, 6, 42], 'B': [7, 8, 10]})
merged_df = pd.concat([df1, df2], ignore_index=True)
expected_df = pd.DataFrame({'A': [1, 2, 26, 5, 6, 42], 'B': [3, 4, 39, 7, 8, 10]})
try:
    pd.testing.assert_frame_equal(merged_df, expected_df)
    print("Test passed!")
except AssertionError as e:
    print("Test failed:", e)


#מבחן על ממוצע 
def calculate_mean_resp_onset(df):
    return df['D'].mean()
def test_calculate_mean_resp_onset():
    data = {'D': [19, 35, 26, 59, 4]}
    test_df = pd.DataFrame(data)

    expected_mean = 28.6  # הממוצע הידוע
    result = calculate_mean_resp_onset(test_df)
    assert result == expected_mean, f"Expected {expected_mean}, but got {result}"
test_calculate_mean_resp_onset()
print("Test passed!")


#מבחן לבדיקת סטיות תקן 
data1 = {'values': np.random.normal(0, 1, 100)}
data2 = {'values': np.random.normal(0, 1, 100)}
df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)
std1 = df1.std()
std2 = df2.std()
std_df1 = pd.DataFrame({'std': std1})
std_df2 = pd.DataFrame({'std': std2})
try:
    pd.testing.assert_frame_equal(std_df1, std_df2)
    print("סטיות התקן שוות בין ה-DataFrames.")
except AssertionError:
    print("סטיות התקן לא שוות בין ה-DataFrames.")


#מבחן על טי טסט 
from scipy.stats import ttest_ind
group_a = [85, 88, 90, 92, 87]
group_b = [80, 78, 82, 85, 79]
t_stat, p_value = ttest_ind(group_a, group_b)
print(f"T-statistic: {t_stat:.2f}, P-value: {p_value:.4f}")

#מבחן על קשר בין משתנים 
from scipy.stats import pearsonr
social_reward = [85, 88, 90, 92, 87]
financial_reward = [80, 78, 82, 85, 79]
# חישוב קורלציה מסוג Pearson
correlation, p_value = pearsonr(social_reward, financial_reward)
# הדפסת התוצאות
print(f"Pearson Correlation: {correlation:.2f}, P-value: {p_value:.4f}")

