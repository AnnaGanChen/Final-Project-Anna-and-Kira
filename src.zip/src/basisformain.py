import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from functools import reduce
import numpy as np

#Ultimatum Task 
#עבור הנבדקים - פר נבדק 
csv_path = r'sourcedata\UGDG\logs\1002\sub-1002_task-ultimatum_run-0_raw.csv'
df_SUB102ULTIMATUM = pd.read_csv(csv_path)
df_SUB102ULTIMATUM.head() #קובץ של מבחן אולטימטום של נבדק ראשון, ייצוג של דאטה פריים 
print(df_SUB102ULTIMATUM.columns)#ייצוג עמודות שמופיעות בקובץ של נבדק 1002 

df_SUB102ULTIMATUM.isnull().sum() #ערכים חסרים (אין)

df_SUB102ULTIMATUM.drop(['ran','nTrial'], axis=1, inplace=True) #מחיקת עמודות לא רלוונטיות עקב איבוד מידע במחקר הקודם 
print(df_SUB102ULTIMATUM.columns) #עמודות שנשארו אחרי הסרה 

df_SUB102ULTIMATUM.drop(['order','L_Option','R_Option'], axis=1, inplace=True) #הסרת עמודות שהמידע מהם נאבד
print(df_SUB102ULTIMATUM.columns) #עמודות שנשארו אחרי הסרה 
df_SUB102ULTIMATUM.head() #יצוג 5 שורות הראשונות של הנתונים 

df_SUB102ULTIMATUM.describe() #תיאור סטטיסטי של הנבדק עבור כל משימה, זמני תגובה  

df_SUB102ULTIMATUM.info() #מידע בנוגע לעמודות/משתנים 

df_SUB102ULTIMATUM.loc[0:36,['endowment_onset', 'endowment_offset']] #בחירת משתנה ''תרומה'' במשחק חברתי כדי בהמשך להבין את זמן התגובה ואת ההשפעה 
df_SUB102ULTIMATUM.loc[0:36,['decision_onset', 'decision_offset']] #בחירת משתנה ''מהירות ההחלטה'' במשחק חברתי כדי בהמשך להבין את זמן התגובה ואת ההשפעה 

index_decision = df_SUB102ULTIMATUM.set_index(['decision_onset', 'decision_offset']) #המרת משתנים לאינדקסים 
index_decision.head()

df_SUB102ULTIMATUM['decision_time_range']=df_SUB102ULTIMATUM['decision_offset']-df_SUB102ULTIMATUM['decision_onset']  #חישוב טווחים של זמן החלטה
df_SUB102ULTIMATUM.loc[0:36,['decision_time_range']]#ייצוג העמודה החדשה של משתנה חדש 

index_endowment = df_SUB102ULTIMATUM.set_index(['endowment_onset', 'endowment_offset'])#המרת משתנים לאינדקסים 
index_endowment.head()

df_SUB102ULTIMATUM['endowment_time_range']=df_SUB102ULTIMATUM['endowment_offset']-df_SUB102ULTIMATUM['endowment_onset']  #חישוב טווחים של זמן תגובה של תרומה 
df_SUB102ULTIMATUM.loc[0:36,['endowment_time_range']]#ייצוג העמודה החדשה של משתנה חדש 

print(df_SUB102ULTIMATUM.columns) #בדיקה שנוצרו עמודות חדשות בדאטה כללי 

mean_decision_time_range = df_SUB102ULTIMATUM['decision_time_range'].mean() #ממוצע של זמן ההחלטה 
print(f"ממוצע של זמן ההחלטה הוא:{mean_decision_time_range}")
mean_endowment_time_range = df_SUB102ULTIMATUM['endowment_time_range'].mean() #ממוצע של זמן מצב תרומה 
print(f"ממוצע של זמן תרומה הוא:{mean_endowment_time_range}")
mean_resp_onset = df_SUB102ULTIMATUM['resp_onset'].mean() #ממוצע של זמן תגובה  
print(f"ממוצע של זמן תגובה הוא:{mean_resp_onset}")

std_decision_time_range = df_SUB102ULTIMATUM['decision_time_range'].std() #סטיית תקן של זמן ההחלטה 
print(f"סטיית תקן של זמן ההחלטה הוא:{std_decision_time_range}")
std_endowment_time_range = df_SUB102ULTIMATUM['endowment_time_range'].std() #סטיית תקן של זמן מצב תרומה 
print(f"סטיית תקן של זמן תרומה הוא:{std_endowment_time_range}")
std_resp_onset = df_SUB102ULTIMATUM['resp_onset'].std() #סטיית תקן של זמן תגובה  
print(f"סטיית תקן של זמן תגובה הוא:{std_resp_onset}")

means = df_SUB102ULTIMATUM.mean() #גרף עבור כל העמודות של אותו הנבדק 
stds = df_SUB102ULTIMATUM.std()
df_SUB102ULTIMATUM.min().plot(kind='bar', color='pink', capsize=4)
plt.bar(means.index, means.values, yerr=stds.values, capsize=4, color='green')
plt.tight_layout()
plt.show()

df_selected = df_SUB102ULTIMATUM[['decision_time_range', 'endowment_time_range', 'resp_onset']] #בחירת 3 משתנים לחישוב קורלציה 
correlation_matrix = df_selected.corr() #חישוב קשר בין המשתנים 
print(correlation_matrix)

sns.scatterplot(x='decision_time_range', y='endowment_time_range', hue='resp_onset', data=df_SUB102ULTIMATUM) #גרף קשר בין שלושת המשתנים
plt.show()
sns.scatterplot(x='decision_time_range', y='endowment_time_range', data=df_SUB102ULTIMATUM) #גרף קשר בין משתנה זמן ההחלטה וזמן תרומה המשתנים
plt.show()
sns.scatterplot(x='resp_onset', y='decision_time_range', data=df_SUB102ULTIMATUM) #גרף קשר בין זמן תגובה לזמן ההחלטה המשתנים
plt.show()
sns.scatterplot(x='resp_onset', y='endowment_time_range', data=df_SUB102ULTIMATUM) #גרף קשר בין זמן תגובה לזמן תרומה המשתנים
plt.show()


csv_path2 = r'sourcedata\UGDG\logs\1003\sub-1003_task-ultimatum_run-0_raw.csv'
df_SUB103ULTIMATUM = pd.read_csv(csv_path2)#קובץ של מבחן אולטימטום של נבדק שני, ייצוג של דאטה פריים 
df_SUB103ULTIMATUM.head() #רק 5 שורות ראשונות 

print(df_SUB103ULTIMATUM.columns)#ייצוג של עמודות/משתנים של נבדק 103 
df_SUB103ULTIMATUM.isnull().sum().sum() #ערכים חסרים (אין) 
df_SUB103ULTIMATUM.drop(['ran','nTrial','order','L_Option','R_Option'], axis=1, inplace=True) #מחיקת עמודות לא רלוונטיות עקב איבוד מידע במחקר הקודם 
print(df_SUB103ULTIMATUM.columns)#ייצוג של עמודות/משתנים של נבדק 103 אחרי החיתוך של העמודות 
df_SUB103ULTIMATUM.head()
df_SUB103ULTIMATUM.describe() #תיאור סטטיסטי של הנבדק עבור כל משימה, זמני תגובה  
df_SUB103ULTIMATUM.info() #מידע בנוגע לנתונים
df_SUB103ULTIMATUM.loc[0:36,['endowment_onset', 'endowment_offset']] #בחירת משתנה ''תרומה'' במשחק חברתי כדי בהמשך להבין את זמן התגובה ואת ההשפעה 
df_SUB103ULTIMATUM.loc[0:36,['decision_onset', 'decision_offset']] #בחירת משתנה ''מהירות ההחלטה'' במשחק חברתי כדי בהמשך להבין את זמן התגובה ואת ההשפעה 

index_decision2 = df_SUB103ULTIMATUM.set_index(['decision_onset', 'decision_offset']) #המרת משתנים לאינדקסים 
index_decision2.head()

df_SUB103ULTIMATUM['decision_time_range']=df_SUB103ULTIMATUM['decision_offset']-df_SUB103ULTIMATUM['decision_onset']  #חישוב טווחים של זמן החלטה
df_SUB103ULTIMATUM.loc[0:36,['decision_time_range']]#ייצוג העמודה החדשה של משתנה חדש 

index_endowment2 = df_SUB103ULTIMATUM.set_index(['endowment_onset', 'endowment_offset'])#המרת משתנים לאינדקסים 
index_endowment2.head()

df_SUB103ULTIMATUM['endowment_time_range']=df_SUB103ULTIMATUM['endowment_offset']-df_SUB103ULTIMATUM['endowment_onset']  #חישוב טווחים של זמן תגובה של תרומה 
df_SUB103ULTIMATUM.loc[0:36,['endowment_time_range']]#ייצוג העמודה החדשה של משתנה חדש 

print(df_SUB103ULTIMATUM.columns) #אחרי איחוד טבלעות 

mean2_decision_time_range=df_SUB103ULTIMATUM['decision_time_range'].mean() #ממוצע של זמן ההחלטה 
print(f"הממוצע של זמן ההחלטה עבור נבדק 2 הוא: {mean2_decision_time_range}")
mean2_endowment_time_range=df_SUB103ULTIMATUM['endowment_time_range'].mean() #ממוצע של מצב תרומה 
print(f"הממוצע של מצב התרומה עבור נבדק 2 הוא: {mean2_endowment_time_range}")
mean2_resp_onset=df_SUB103ULTIMATUM['resp_onset'].mean() #ממוצע של תחילת זמן תגובה 
print(f"הממוצע של תחילת זמן תגובה עבור נבדק 2 הוא: {mean2_resp_onset}")

std2_decision_time_range = df_SUB103ULTIMATUM['decision_time_range'].std() #סטיית תקן של זמן ההחלטה 
print(f"סטיית תקן של זמן ההחלטה הוא:{std2_decision_time_range}")
std2_endowment_time_range = df_SUB103ULTIMATUM['endowment_time_range'].std() #סטיית תקן של זמן מצב תרומה 
print(f"סטיית תקן של זמן תרומה הוא:{std2_endowment_time_range}")
std2_resp_onset = df_SUB103ULTIMATUM['resp_onset'].std() #סטיית תקן של זמן תגובה  
print(f"סטיית תקן של זמן תגובה הוא:{std2_resp_onset}")

means = df_SUB103ULTIMATUM.mean() #גרף עבור כל העמודות של אותו הנבדק 
stds = df_SUB103ULTIMATUM.std()
plt.bar(means.index, means.values, yerr=stds.values, capsize=4, color='brown')
plt.tight_layout()
plt.xticks(rotation=45)
plt.show()

df_selected2 = df_SUB103ULTIMATUM[['decision_time_range', 'endowment_time_range', 'resp_onset']] #בחירת 3 משתנים לחישוב קורלציה 
correlation_matrix2 = df_selected2.corr() #חישוב קשר בין המשתנים 
print(correlation_matrix2)

sns.scatterplot(x='decision_time_range', y='endowment_time_range', hue='resp_onset', data=df_SUB103ULTIMATUM) #גרף קשר בין שלושת המשתנים
plt.show()
sns.scatterplot(x='decision_time_range', y='endowment_time_range', data=df_SUB103ULTIMATUM) #גרף קשר בין משתנה זמן ההחלטה וזמן תרומה המשתנים
plt.show()
sns.scatterplot(x='resp_onset', y='endowment_time_range', data=df_SUB103ULTIMATUM) #גרף קשר בין זמן תגובה לזמן תרומה המשתנים
plt.show()

#קריאת קבצים של כל הנבדקים (copy your pathway for the documents)
csv_path3 = r'sourcedata\UGDG\logs\1004\sub-1004_task-ultimatum_run-0_raw.csv'
df_SUB104ULTIMATUM = pd.read_csv(csv_path3)#קובץ של מבחן אולטימטום של נבדק שלישי, ייצוג של דאטה פריים 
df_SUB104ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path4 = r'sourcedata\UGDG\logs\1006\sub-1006_task-ultimatum_run-0_raw.csv'
df_SUB106ULTIMATUM = pd.read_csv(csv_path4)#קובץ של מבחן אולטימטום של נבדק רביעי, ייצוג של דאטה פריים 
df_SUB106ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path5 = r'sourcedata\UGDG\logs\1007\sub-1007_task-ultimatum_run-0_raw.csv'
df_SUB107ULTIMATUM = pd.read_csv(csv_path5)#קובץ של מבחן אולטימטום של נבדק חמישי, ייצוג של דאטה פריים 
df_SUB107ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path6 = r'sourcedata\UGDG\logs\1009\sub-1009_task-ultimatum_run-0_raw.csv'
df_SUB109ULTIMATUM = pd.read_csv(csv_path6)#קובץ של מבחן אולטימטום של נבדק שישי, ייצוג של דאטה פריים 
df_SUB109ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path7 = r'sourcedata\UGDG\logs\1010\sub-1010_task-ultimatum_run-0_raw.csv'
df_SUB110ULTIMATUM = pd.read_csv(csv_path7)#קובץ של מבחן אולטימטום של נבדק שביעי, ייצוג של דאטה פריים 
df_SUB110ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path8 = r'sourcedata\UGDG\logs\1011\sub-1011_task-ultimatum_run-0_raw.csv'
df_SUB111ULTIMATUM = pd.read_csv(csv_path8)#קובץ של מבחן אולטימטום של נבדק שמיני, ייצוג של דאטה פריים 
df_SUB111ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path9 = r'sourcedata\UGDG\logs\1012\sub-1012_task-ultimatum_run-0_raw.csv'
df_SUB112ULTIMATUM = pd.read_csv(csv_path9)#קובץ של מבחן אולטימטום של נבדק תשיעי, ייצוג של דאטה פריים 
df_SUB112ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path10 = r'sourcedata\UGDG\logs\1013\sub-1013_task-ultimatum_run-0_raw.csv'
df_SUB113ULTIMATUM = pd.read_csv(csv_path10)#קובץ של מבחן אולטימטום של נבדק עשירי, ייצוג של דאטה פריים 
df_SUB113ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path11 = r'sourcedata\UGDG\logs\1015\sub-1015_task-ultimatum_run-0_raw.csv'
df_SUB115ULTIMATUM = pd.read_csv(csv_path11)#קובץ של מבחן אולטימטום של נבדק אחד עשרה, ייצוג של דאטה פריים 
df_SUB115ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path12 = r'sourcedata\UGDG\logs\1016\sub-1016_task-ultimatum_run-0_raw.csv'
df_SUB116ULTIMATUM = pd.read_csv(csv_path12)#קובץ של מבחן אולטימטום של נבדק שתיים עשרה, ייצוג של דאטה פריים 
df_SUB116ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path13 = r'sourcedata\UGDG\logs\1019\sub-1019_task-ultimatum_run-0_raw.csv'
df_SUB119ULTIMATUM = pd.read_csv(csv_path13)#קובץ של מבחן אולטימטום של נבדק שלוש עשרה, ייצוג של דאטה פריים 
df_SUB119ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path14 = r'sourcedata\UGDG\logs\1021\sub-1021_task-ultimatum_run-0_raw.csv'
df_SUB1021ULTIMATUM = pd.read_csv(csv_path14)#קובץ של מבחן אולטימטום של נבדק ארבע עשרה, ייצוג של דאטה פריים 
df_SUB1021ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path15 = r'sourcedata\UGDG\logs\1240\sub-1240_task-ultimatum_run-0_raw.csv'
df_SUB1240ULTIMATUM = pd.read_csv(csv_path15)#קובץ של מבחן אולטימטום של נבדק חמש עשרה, ייצוג של דאטה פריים 
df_SUB1240ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path16 = r'sourcedata\UGDG\logs\1242\sub-1242_task-ultimatum_run-0_raw.csv'
df_SUB1242ULTIMATUM = pd.read_csv(csv_path16)#קובץ של מבחן אולטימטום של נבדק שש עשרה, ייצוג של דאטה פריים 
df_SUB1242ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path17 = r'sourcedata\UGDG\logs\1243\sub-1243_task-ultimatum_run-0_raw.csv'
df_SUB1243ULTIMATUM = pd.read_csv(csv_path17)#קובץ של מבחן אולטימטום של נבדק שבע עשרה, ייצוג של דאטה פריים 
df_SUB1243ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path18 = r'sourcedata\UGDG\logs\1244\sub-1244_task-ultimatum_run-0_raw.csv'
df_SUB1244ULTIMATUM = pd.read_csv(csv_path18)#קובץ של מבחן אולטימטום של נבדק שמונה עשרה, ייצוג של דאטה פריים 
df_SUB1244ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path19 = r'sourcedata\UGDG\logs\1245\sub-1245_task-ultimatum_run-0_raw.csv'
df_SUB1245ULTIMATUM = pd.read_csv(csv_path19)#קובץ של מבחן אולטימטום של נבדק תשע עשרה, ייצוג של דאטה פריים 
df_SUB1245ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path20 = r'sourcedata\UGDG\logs\1247\sub-1247_task-ultimatum_run-0_raw.csv'
df_SUB1247ULTIMATUM = pd.read_csv(csv_path20)#קובץ של מבחן אולטימטום של נבדק עשרים, ייצוג של דאטה פריים 
df_SUB1247ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path21 = r'sourcedata\UGDG\logs\1248\sub-1248_task-ultimatum_run-0_raw.csv'
df_SUB1248ULTIMATUM = pd.read_csv(csv_path21)#קובץ של מבחן אולטימטום של נבדק עשרים ואחד, ייצוג של דאטה פריים 
df_SUB1248ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path22 = r'sourcedata\UGDG\logs\1249\sub-1249_task-ultimatum_run-0_practice_raw.csv'
df_SUB1249ULTIMATUM = pd.read_csv(csv_path22)#קובץ של מבחן אולטימטום של נבדק עשרים ושתיים, ייצוג של דאטה פריים 
df_SUB1249ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path23 = r'sourcedata\UGDG\logs\1251\sub-1251_task-ultimatum_run-0_raw.csv'
df_SUB1251ULTIMATUM = pd.read_csv(csv_path23)#קובץ של מבחן אולטימטום של נבדק עשרים ושלוש, ייצוג של דאטה פריים 
df_SUB1251ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path24 = r'sourcedata\UGDG\logs\1253\sub-1253_task-ultimatum_run-0_raw.csv'
df_SUB1253ULTIMATUM = pd.read_csv(csv_path24)#קובץ של מבחן אולטימטום של נבדק עשרים וארבע, ייצוג של דאטה פריים 
df_SUB1253ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path25 = r'sourcedata\UGDG\logs\1255\sub-1255_task-ultimatum_run-0_practice_raw.csv'
df_SUB1255ULTIMATUM = pd.read_csv(csv_path25)#קובץ של מבחן אולטימטום של נבדק עשרים וחמש, ייצוג של דאטה פריים 
df_SUB1255ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path26 = r'sourcedata\UGDG\logs\1276\sub-1276_task-ultimatum_run-0_raw.csv'
df_SUB1276ULTIMATUM = pd.read_csv(csv_path26)#קובץ של מבחן אולטימטום של נבדק עשרים ושש, ייצוג של דאטה פריים 
df_SUB1276ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path27 = r'sourcedata\UGDG\logs\1282\sub-1282_task-ultimatum_run-0_practice_raw.csv'
df_SUB1282ULTIMATUM = pd.read_csv(csv_path27)#קובץ של מבחן אולטימטום של נבדק עשרים ושבע, ייצוג של דאטה פריים 
df_SUB1282ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path28 = r'sourcedata\UGDG\logs\1286\sub-1286_task-ultimatum_run-0_raw.csv'
df_SUB1286ULTIMATUM = pd.read_csv(csv_path28)#קובץ של מבחן אולטימטום של נבדק עשרים ושמונה, ייצוג של דאטה פריים 
df_SUB1286ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path29 = r'sourcedata\UGDG\logs\1294\sub-1294_task-ultimatum_run-0_raw.csv'
df_SUB1294ULTIMATUM = pd.read_csv(csv_path29)#קובץ של מבחן אולטימטום של נבדק עשרים ותשע, ייצוג של דאטה פריים 
df_SUB1294ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path30 = r'sourcedata\UGDG\logs\1300\sub-1300_task-ultimatum_run-0_raw.csv'
df_SUB1300ULTIMATUM = pd.read_csv(csv_path30)#קובץ של מבחן אולטימטום של נבדק שלושים, ייצוג של דאטה פריים 
df_SUB1300ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path31 = r'sourcedata\UGDG\logs\1301\sub-1301_task-ultimatum_run-0_raw.csv'
df_SUB1301ULTIMATUM = pd.read_csv(csv_path31)#קובץ של מבחן אולטימטום של נבדק שלושים ואחד, ייצוג של דאטה פריים 
df_SUB1301ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path32 = r'sourcedata\UGDG\logs\1302\sub-1302_task-ultimatum_run-0_raw.csv'
df_SUB1302ULTIMATUM = pd.read_csv(csv_path32)#קובץ של מבחן אולטימטום של נבדק שלושים ושתיים, ייצוג של דאטה פריים 
df_SUB1302ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path33 = r'sourcedata\UGDG\logs\1303\sub-1303_task-ultimatum_run-0_raw.csv'
df_SUB1303ULTIMATUM = pd.read_csv(csv_path33)#קובץ של מבחן אולטימטום של נבדק שלושים ושלוש, ייצוג של דאטה פריים 
df_SUB1303ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path34 = r'sourcedata\UGDG\logs\3101\sub-3101_task-ultimatum_run-0_raw.csv'
df_SUB3101ULTIMATUM = pd.read_csv(csv_path34)#קובץ של מבחן אולטימטום של נבדק שלושים וארבע, ייצוג של דאטה פריים 
df_SUB3101ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path35 = r'sourcedata\UGDG\logs\3116\sub-3116_task-ultimatum_run-0_raw.csv'
df_SUB3116ULTIMATUM = pd.read_csv(csv_path35)#קובץ של מבחן אולטימטום של נבדק שלושים וחמש, ייצוג של דאטה פריים 
df_SUB3116ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path36 = r'sourcedata\UGDG\logs\3122\sub-3122_task-ultimatum_run-0_raw.csv'
df_SUB3122ULTIMATUM = pd.read_csv(csv_path36)#קובץ של מבחן אולטימטום של נבדק שלושים ושש, ייצוג של דאטה פריים 
df_SUB3122ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path37 = r'sourcedata\UGDG\logs\3125\sub-3125_task-ultimatum_run-0_raw.csv'
df_SUB3125ULTIMATUM = pd.read_csv(csv_path37)#קובץ של מבחן אולטימטום של נבדק שלושים ושבע, ייצוג של דאטה פריים 
df_SUB3125ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path38 = r'sourcedata\UGDG\logs\3140\sub-3140_task-ultimatum_run-0_raw.csv'
df_SUB3140ULTIMATUM = pd.read_csv(csv_path38)#קובץ של מבחן אולטימטום של נבדק שלושים ושמונה, ייצוג של דאטה פריים 
df_SUB3140ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path39 = r'sourcedata\UGDG\logs\3143\sub-3143_task-ultimatum_run-0_raw.csv'
df_SUB3143ULTIMATUM = pd.read_csv(csv_path39)#קובץ של מבחן אולטימטום של נבדק שלושים ותשע, ייצוג של דאטה פריים 
df_SUB3143ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path40 = r'sourcedata\UGDG\logs\3152\sub-3152_task-ultimatum_run-0_raw.csv'
df_SUB3152ULTIMATUM = pd.read_csv(csv_path40)#קובץ של מבחן אולטימטום של נבדק ארבעים, ייצוג של דאטה פריים 
df_SUB3152ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path41 = r'sourcedata\UGDG\logs\3164\sub-3164_task-ultimatum_run-0_raw.csv'
df_SUB3164ULTIMATUM = pd.read_csv(csv_path41)#קובץ של מבחן אולטימטום של נבדק ארבעים ואחד, ייצוג של דאטה פריים 
df_SUB3164ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path42 = r'sourcedata\UGDG\logs\3166\sub-3166_task-ultimatum_run-0_raw.csv'
df_SUB3166ULTIMATUM = pd.read_csv(csv_path42)#קובץ של מבחן אולטימטום של נבדק ארבעים ושתיים, ייצוג של דאטה פריים 
df_SUB3166ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path43 = r'sourcedata\UGDG\logs\3167\sub-3167_task-ultimatum_run-0_raw.csv'
df_SUB3167ULTIMATUM = pd.read_csv(csv_path43)#קובץ של מבחן אולטימטום של נבדק ארבעים ושלוש, ייצוג של דאטה פריים 
df_SUB3167ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path44 = r'sourcedata\UGDG\logs\3170\sub-3170_task-ultimatum_run-0_raw.csv'
df_SUB3170ULTIMATUM = pd.read_csv(csv_path44)#קובץ של מבחן אולטימטום של נבדק ארבעים וארבע, ייצוג של דאטה פריים 
df_SUB3170ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path45 = r'sourcedata\UGDG\logs\3173\sub-3173_task-ultimatum_run-0_raw.csv'
df_SUB3173ULTIMATUM = pd.read_csv(csv_path45)#קובץ של מבחן אולטימטום של נבדק ארבעים וחמש, ייצוג של דאטה פריים 
df_SUB3173ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path46 = r'sourcedata\UGDG\logs\3175\sub-3175_task-ultimatum_run-0_raw.csv'
df_SUB3175ULTIMATUM = pd.read_csv(csv_path46)#קובץ של מבחן אולטימטום של נבדק ארבעים ושש, ייצוג של דאטה פריים 
df_SUB3175ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path47 = r'sourcedata\UGDG\logs\3176\sub-3176_task-ultimatum_run-0_raw.csv'
df_SUB3176ULTIMATUM = pd.read_csv(csv_path47)#קובץ של מבחן אולטימטום של נבדק ארבעים ושבע, ייצוג של דאטה פריים 
df_SUB3176ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path48 = r'sourcedata\UGDG\logs\3186\sub-3186_task-ultimatum_run-0_raw.csv'
df_SUB3186ULTIMATUM = pd.read_csv(csv_path48)#קובץ של מבחן אולטימטום של נבדק ארבעים ושמונה, ייצוג של דאטה פריים 
df_SUB3186ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path49 = r'sourcedata\UGDG\logs\3189\sub-3189_task-ultimatum_run-0_raw.csv'
df_SUB3189ULTIMATUM = pd.read_csv(csv_path49)#קובץ של מבחן אולטימטום של נבדק ארבעים ותשע, ייצוג של דאטה פריים 
df_SUB3189ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path50 = r'sourcedata\UGDG\logs\3190\sub-3190_task-ultimatum_run-0_raw.csv'
df_SUB3190ULTIMATUM = pd.read_csv(csv_path50)#קובץ של מבחן אולטימטום של נבדק חמישים, ייצוג של דאטה פריים 
df_SUB3190ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path51 = r'sourcedata\UGDG\logs\3199\sub-3199_task-ultimatum_run-0_raw.csv'
df_SUB3199ULTIMATUM = pd.read_csv(csv_path51)#קובץ של מבחן אולטימטום של נבדק חמישים ואחד, ייצוג של דאטה פריים 
df_SUB3199ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path52 = r'sourcedata\UGDG\logs\3200\sub-3200_task-ultimatum_run-0_raw.csv'
df_SUB3200ULTIMATUM = pd.read_csv(csv_path52)#קובץ של מבחן אולטימטום של נבדק חמישים ושתיים, ייצוג של דאטה פריים 
df_SUB3200ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path53 = r'sourcedata\UGDG\logs\3206\sub-3206_task-ultimatum_run-0_raw.csv'
df_SUB3206ULTIMATUM = pd.read_csv(csv_path53)#קובץ של מבחן אולטימטום של נבדק חמישים ושלוש, ייצוג של דאטה פריים 
df_SUB3206ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path54 = r'sourcedata\UGDG\logs\3210\sub-3210_task-ultimatum_run-0_raw.csv '
df_SUB3210ULTIMATUM = pd.read_csv(csv_path54)#קובץ של מבחן אולטימטום של נבדק חמישים וארבע, ייצוג של דאטה פריים 
df_SUB3210ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path55 = r'sourcedata\UGDG\logs\3212\sub-3212_task-ultimatum_run-0_raw.csv '
df_SUB3212ULTIMATUM = pd.read_csv(csv_path55)#קובץ של מבחן אולטימטום של נבדק חמישים וחמש, ייצוג של דאטה פריים 
df_SUB3212ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path56 = r'sourcedata\UGDG\logs\3218\sub-3218_task-ultimatum_run-0_raw.csv '
df_SUB3218ULTIMATUM = pd.read_csv(csv_path56)#קובץ של מבחן אולטימטום של נבדק חמישים ושש, ייצוג של דאטה פריים 
df_SUB3218ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path57 = r'sourcedata\UGDG\logs\3220\sub-3220_task-ultimatum_run-0_raw.csv '
df_SUB3220ULTIMATUM = pd.read_csv(csv_path57)#קובץ של מבחן אולטימטום של נבדק חמישים ושבע, ייצוג של דאטה פריים 
df_SUB3220ULTIMATUM.head() #רק 5 שורות ראשונות 
csv_path58 = r'sourcedata\UGDG\logs\3223\sub-3223_task-ultimatum_run-0_raw.csv '
df_SUB3223ULTIMATUM = pd.read_csv(csv_path58)#קובץ של מבחן אולטימטום של נבדק חמישים ושמונה, ייצוג של דאטה פריים 
df_SUB3223ULTIMATUM.head() #רק 5 שורות ראשונות 


#איחוד בין כל הטבלעות 
dfs = [
    df_SUB102ULTIMATUM, df_SUB3125ULTIMATUM, df_SUB3122ULTIMATUM, df_SUB3116ULTIMATUM,
    df_SUB3101ULTIMATUM, df_SUB1303ULTIMATUM, df_SUB1302ULTIMATUM, df_SUB1301ULTIMATUM,
    df_SUB1300ULTIMATUM, df_SUB1294ULTIMATUM, df_SUB1286ULTIMATUM, df_SUB1282ULTIMATUM,
    df_SUB1276ULTIMATUM, df_SUB1255ULTIMATUM, df_SUB1253ULTIMATUM, df_SUB1251ULTIMATUM,
    df_SUB1249ULTIMATUM, df_SUB1248ULTIMATUM, df_SUB1247ULTIMATUM, df_SUB1245ULTIMATUM,
    df_SUB1244ULTIMATUM, df_SUB1243ULTIMATUM, df_SUB1242ULTIMATUM, df_SUB103ULTIMATUM,
    df_SUB104ULTIMATUM, df_SUB106ULTIMATUM, df_SUB107ULTIMATUM, df_SUB109ULTIMATUM,
    df_SUB110ULTIMATUM, df_SUB111ULTIMATUM, df_SUB112ULTIMATUM, df_SUB113ULTIMATUM,
    df_SUB115ULTIMATUM, df_SUB116ULTIMATUM, df_SUB119ULTIMATUM, df_SUB1021ULTIMATUM,
    df_SUB1240ULTIMATUM, df_SUB3140ULTIMATUM, df_SUB3143ULTIMATUM, df_SUB3152ULTIMATUM, df_SUB3164ULTIMATUM,df_SUB3166ULTIMATUM,
    df_SUB3167ULTIMATUM, df_SUB3170ULTIMATUM, df_SUB3173ULTIMATUM, df_SUB3175ULTIMATUM, df_SUB3176ULTIMATUM, 
    df_SUB3186ULTIMATUM, df_SUB3189ULTIMATUM, df_SUB3190ULTIMATUM, df_SUB3199ULTIMATUM, df_SUB3200ULTIMATUM, 
    df_SUB3206ULTIMATUM, df_SUB3210ULTIMATUM, df_SUB3212ULTIMATUM, df_SUB3218ULTIMATUM, df_SUB3220ULTIMATUM, df_SUB3223ULTIMATUM
]
merged_df = pd.concat(dfs, ignore_index=True)
merged_df

merged_df.info()
merged_df.describe()
merged_df.isnull().sum() #כאן לא ביצענו ניקוי של desision time range וendowment rage .כי זה פר נבדק, בהמשך חישבנו את המשתנים הרלוונטים בבין נבדקי 
print(merged_df.columns)
merged_df.drop(['ran', 'nTrial', 'L_Option','L_Option', 'order'], axis=1, inplace=True)
print(merged_df.columns)
merged_df.head()
merged_df.iloc[0:2125, [merged_df.columns.get_loc('decision_onset'), merged_df.columns.get_loc('decision_offset')]]
indexfordecision=merged_df.set_index(['decision_onset', 'decision_offset']) #המרת עמודות לאינדקסים
print(merged_df.columns)
indexfordecision=merged_df.set_index(['decision_onset', 'decision_offset'])
indexfordecision.head() 

merged_df['decision_offset'] = pd.to_numeric(merged_df['decision_offset'], errors='coerce') #המרה למשתנה מספרי
merged_df['decision_onset'] = pd.to_numeric(merged_df['decision_onset'], errors='coerce')

merged_df['decision_time_range_for_all'] = merged_df['decision_offset'] - merged_df['decision_onset']#חישוב טווח ויצירת משתנה חדש 
merged_df.iloc[0:2125, [merged_df.columns.get_loc('decision_time_range_for_all')]] #יצוג של התוצאה בתור משתנה חדש

merged_df.iloc[0:2125, [merged_df.columns.get_loc('endowment_onset'), merged_df.columns.get_loc('endowment_offset')]] #ייצוג משתנה תמורה
indexfordecision=merged_df.set_index(['endowment_onset', 'endowment_offset']) #המרת עמודות לאינדקסים
indexfordecision.head() 

merged_df['endowment_offset'] = pd.to_numeric(merged_df['endowment_offset'], errors='coerce') #המרה למשתנה מספרי
merged_df['endowment_onset'] = pd.to_numeric(merged_df['endowment_onset'], errors='coerce')

merged_df['endowment_time_range_for_all'] = merged_df['endowment_offset'] - merged_df['endowment_onset']#חישוב טווח ויצירת משתנה חדש 
merged_df.iloc[0:2125, [merged_df.columns.get_loc('endowment_time_range_for_all')]] #יצוג של התוצאה בתור משתנה חדש

print(merged_df.columns) #בדיקה שנוצרו 2 עמודות חדשות 

merged_df['resp_onset'] = pd.to_numeric(merged_df['resp_onset'], errors='coerce') #המרה למשתנה מספרי

mean_decision_time_range_for_all=merged_df['decision_time_range_for_all'].mean() #בין נבדקי - ממוצע של זמן ההחלטה 
print(f"הממוצע של זמן ההחלטה עבור כל הנבדקים הוא: {mean_decision_time_range_for_all}")
mean_endowment_time_range_for_all=merged_df['endowment_time_range_for_all'].mean() #ממוצע של מצב תרומה - בין נבדקי
print(f"הממוצע של מצב התרומה עבור כל הנבדקים הוא: {mean_endowment_time_range_for_all}")
mean_resp_onset_for_all=merged_df['resp_onset'].mean() #ממוצע של תחילת זמן תגובה - בין נבדקי
print(f"הממוצע של תחילת זמן תגובה עבור כל הנבדקים הוא: {mean_resp_onset_for_all}")

std_decision_time_range_for_all = merged_df['decision_time_range_for_all'].std() #סטיית תקן של זמן ההחלטה 
print(f"סטיית תקן של זמן ההחלטה הוא:{std_decision_time_range_for_all}")
std_endowment_time_range_for_all = merged_df['endowment_time_range_for_all'].std() #סטיית תקן של זמן מצב תרומה 
print(f"סטיית תקן של זמן תרומה הוא:{std_endowment_time_range_for_all}")
std_resp_onset_for_all = merged_df['resp_onset'].std() #סטיית תקן של זמן תגובה  
print(f"סטיית תקן של זמן תגובה הוא:{std_resp_onset_for_all}")

mean_values = [mean_decision_time_range_for_all, mean_endowment_time_range_for_all, mean_resp_onset_for_all] #תיאור נתונים עבורם מייצרת את הגרף
std_values = [std_decision_time_range_for_all, std_endowment_time_range_for_all, std_resp_onset_for_all]
labels = ['Decision Time', 'Endowment Time', 'Response Onset'] 
x = np.arange(len(labels))  # יצירת גרף
fig, ax = plt.subplots(figsize=(10, 8)) #עמודות עבור ממוצעים
ax.bar(x, mean_values, yerr=std_values, capsize=5, color='skyblue', edgecolor='black')
ax.set_ylabel('Time (seconds)') #תוויות
ax.set_title('Mean Values with Standard Deviations')
ax.set_xticks(x)
ax.set_xticklabels(labels)
plt.tight_layout() #הצגה של הגרף 
plt.show()

merged_df_selected = merged_df[['decision_time_range_for_all', 'endowment_time_range_for_all', 'resp_onset']] #בחירת 3 משתנים לחישוב קורלציה 
correlation_matrix_for_all = merged_df_selected.corr() #חישוב קשר בין המשתנים 
correlation_matrix_for_all  

sns.scatterplot(x='decision_time_range_for_all', y='endowment_time_range_for_all', hue='resp_onset', data=merged_df) #גרף קשר בין שלושת המשתנים
sns.regplot(x='decision_time_range_for_all', y='endowment_time_range_for_all', scatter=False, data=merged_df, line_kws={"color": "red"}) 
sns.regplot(x='resp_onset', y='decision_time_range_for_all', scatter=False, data=merged_df, line_kws={"color": "orange"}) 
sns.regplot(x='resp_onset', y='endowment_time_range_for_all', scatter=False, data=merged_df, line_kws={"color": "blue"}) 
plt.show()
sns.scatterplot(x='decision_time_range_for_all', y='endowment_time_range_for_all', data=merged_df) #גרף קשר בין משתנה זמן ההחלטה וזמן תרומה המשתנים
sns.regplot(x='decision_time_range_for_all', y='endowment_time_range_for_all', data=merged_df, scatter=False, line_kws={'color': 'red'})
plt.show()
sns.scatterplot(x='resp_onset', y='decision_time_range_for_all', data=merged_df) #גרף קשר בין זמן תגובה לזמן ההחלטה המשתנים
sns.regplot(x='resp_onset', y='decision_time_range_for_all', data=merged_df, scatter=False, line_kws={'color': 'red'})
plt.show()
sns.scatterplot(x='resp_onset', y='endowment_time_range_for_all', data=merged_df) #גרף קשר בין זמן תגובה לזמן תרומה המשתנים
sns.regplot(x='resp_onset', y='endowment_time_range_for_all', data=merged_df, scatter=False, line_kws={'color': 'red'})
plt.show()

#חלוקה למשתנים הרלוונטים 
# יצירת שני משתנים חדשים בעמודות:
merged_df['social_reward'] = merged_df['endowment_time_range_for_all'].apply(lambda x: x if x < mean_endowment_time_range_for_all  else None) #תגובה בתרומה מהירה מאוד - תגמול חברתי
merged_df['financial_reward'] = merged_df['endowment_time_range_for_all'].apply(lambda x: x if x > mean_endowment_time_range_for_all  else None) #תגובה במרומה איטית מאוד - תגמול כלכלי
merged_df# הצגת התוצאות

print(merged_df.columns) #בדיקה האם נוצרות עמודות חדשות 

merged_df.iloc[0:2125, [merged_df.columns.get_loc('social_reward'), merged_df.columns.get_loc('financial_reward')]]
merged_df['social_reward'].isnull().sum().sum() #Nan ייצוג של כמות 
merged_df['financial_reward'].isnull().sum().sum() #Nan ייצוג של כמות 
max_value_social_reward = merged_df['social_reward'].max()
print(max_value_social_reward)

max_value_financial_reward = merged_df['financial_reward'].max()
print(max_value_financial_reward)

merged_df["social_reward"] = merged_df["social_reward"].fillna(merged_df["social_reward"].max()) #מילוי ערכים חסרים על ידי מקסימום 
merged_df["financial_reward"] = pd.to_numeric(merged_df["financial_reward"], errors='coerce')
merged_df["financial_reward"] = merged_df["financial_reward"].fillna(merged_df["financial_reward"].max()) # מילוי ערכים חסרים על ידי מקסימום 

merged_df['social_reward'].isnull().sum().sum() # בדיקה שהמילוי עבד 
merged_df.iloc[0:2125, [merged_df.columns.get_loc('social_reward'), merged_df.columns.get_loc('financial_reward')]]

mean_social_reward=merged_df['social_reward'].mean()
print(f"הממוצע של תגמול חברתי עבור כל הנבדקים הוא: {mean_social_reward}")
mean_financial_reward=merged_df['financial_reward'].mean() 
print(f"הממוצע של תגמול כלכלי עבור כל הנבדקים הוא: {mean_financial_reward}")

std_social_reward = merged_df['social_reward'].std() 
print(f"סטיית תקן של תגמול חברתי עבור כל הנבדקים הוא:{std_social_reward}")
std_financial_reward = merged_df['financial_reward'].std() 
print(f"סטיית תקן של תגמול כלכלי עבור כל הנבדקים  הוא:{std_financial_reward}")

mean_values = [mean_social_reward*100, mean_financial_reward*100, mean_resp_onset_for_all] # הוכפל כדי לראות את גובהה העמודות ולהבחין טוב יותר כי הנתונים בשניות ,תיאור נתונים עבורם מייצרת את הגרף
std_values = [std_social_reward,std_financial_reward, std_resp_onset_for_all]
labels = ['Social_reward Time', 'Financial_reward Time', 'Response Onset'] 
x = np.arange(len(labels))  # יצירת גרף
fig, ax = plt.subplots(figsize=(10, 16)) #עמודות עבור ממוצעים
ax.bar(x, mean_values, yerr=std_values, capsize=5, color='skyblue', edgecolor='black')
ax.set_ylabel('Time (seconds)') #תוויות
ax.set_title('Mean Values with Standard Deviations')
ax.set_xticks(x)
ax.set_xticklabels(labels)
plt.tight_layout() #הצגה של הגרף 
plt.show()

merged_df_selectedvarebles = merged_df[['social_reward', 'financial_reward', 'resp_onset']] #בחירת 3 משתנים לחישוב קורלציה 
correlation_varibales = merged_df_selectedvarebles.corr() #חישוב קשר בין המשתנים 
print(correlation_varibales)

sns.scatterplot(x='social_reward', y='financial_reward', hue='resp_onset', data=merged_df) #גרף קשר בין שלושת המשתנים
sns.regplot(x='social_reward', y='financial_reward', scatter=False, data=merged_df, line_kws={"color": "red"}) 
sns.regplot(x='resp_onset', y='financial_reward', scatter=False, data=merged_df, line_kws={"color": "orange"}) 
sns.regplot(x='resp_onset', y='social_reward', scatter=False, data=merged_df, line_kws={"color": "blue"}) 
plt.show()

#ניתוח שאלונים 
#AQ שאלון 
# Import TSV file
pathmy = r'phenotype/autism_quotient.tsv'
dfaq = pd.read_csv(pathmy, sep='\t')
(dfaq.head()) # Display the first few rows
pd.set_option("display.max_rows", 100)  # Adjust to the number of rows you want
pd.set_option("display.max_columns", 50)  # Adjust to the number of columns you want
pd.set_option("display.width", 1000)  # Adjust to avoid wrapping lines

# Path to TSV file 
file_path = r'phenotype/autism_quotient.tsv'
# Load the data
dfaq = pd.read_csv(file_path, sep="\t")
(dfaq.head())
# Check the column names
# Define positive and negative columns (make sure these exist in the DataFrame)
positive_columns = ["aq_2", "aq_4", "aq_5", "aq_6", "aq_7", "aq_9", "aq_12", "aq_13", "aq_16", "aq_18", "aq_19",
                    "aq_20", "aq_21", "aq_22", "aq_23", "aq_26", "aq_33", "aq_35", "aq_39", "aq_41", "aq_42",
                    "aq_43", "aq_45", "aq_46"]

negative_columns = ["aq_1", "aq_3", "aq_8", "aq_10", "aq_11", "aq_14", "aq_15", "aq_17", "aq_24", "aq_25", "aq_27",
                    "aq_28", "aq_29", "aq_30", "aq_31", "aq_32", "aq_34", "aq_36", "aq_37", "aq_38", "aq_40", "aq_44",
                    "aq_47", "aq_48", "aq_49", "aq_50"]

# Ensure the columns exist before proceeding
missing_positive = [col for col in positive_columns if col not in dfaq.columns]
missing_negative = [col for col in negative_columns if col not in dfaq.columns]
if missing_positive or missing_negative:
    ("Missing columns:")

else:
    # Apply positive scoring
    dfaq[positive_columns] = dfaq[positive_columns].applymap(lambda x: 1 if x in [0, 1] else 0)

    # Apply negative scoring
    dfaq[negative_columns] = dfaq[negative_columns].applymap(lambda x: 1 if x in [3, 4] else 0)

    # Calculate final score
    dfaq["Final_aq_score"] = dfaq[positive_columns].sum(axis=1) + dfaq[negative_columns].sum(axis=1)

(dfaq.head())

result= dfaq[["participant_id", "Final_aq_score"]]
#I'm creating a new data frame that only includes their id and final score
(result.head())

(dfaq["Final_aq_score"].mean())
(dfaq["Final_aq_score"].median())
(dfaq["Final_aq_score"].mode())

# Create a new column categorizing participants by their Final_aq_score
dfaq["Group"] = dfaq["Final_aq_score"].apply(lambda x: "Clinical" if x > 25 else "Non-Clinical")  # noqa: PLR2004

# Group by the new category and compute statistics (e.g., count, mean)
grouped = dfaq.groupby("Group")["Final_aq_score"].agg(["count", "mean", "std"])

# Print the grouped statistics
(grouped)


# Select the relevant columns: Participant, Final Score, and Group
result = dfaq[["participant_id", "Final_aq_score", "Group"]]
# Print the result
(result.head())

pathmy1 = r'phenotype/altman_self_rating_mania_scale.tsv'
dfmania = pd.read_csv(pathmy1, delimiter="\t")
(dfmania.head())

file_path_altman = r'phenotype/altman_self_rating_mania_scale.tsv'
# loading altman data
dfmania = pd.read_csv(file_path_altman, sep="\t")
(dfmania.columns)

answers_altman= ["asrm_q1", "asrm_q2", "asrm_q3", "asrm_q4", "asrm_q5"]
dfmania[answers_altman] = dfmania[answers_altman].fillna(0) #this is what fixed the na problem. puts 0 in case of na.
dfmania = dfmania.dropna(subset=answers_altman)
dfmania[answers_altman] = dfmania[answers_altman].apply(pd.to_numeric, errors="coerce")
dfmania["answers_altman_sum"] = dfmania[answers_altman].sum(axis=1)
result_mania_sum = dfmania[["participant_id", "answers_altman_sum"]]
(result_mania_sum.head())

dfmania["Group"] = dfmania["answers_altman_sum"].apply(lambda x: "Clinical" if x > 6 else "Non-Clinical")  # noqa: PLR2004
grouped = dfmania.groupby("Group")["answers_altman_sum"].agg(["count", "mean", "std"])
(grouped)

#dfmania = dfmania.reset_index().rename(columns={"index": "participant_id"})  # noqa: ERA001
results_altman_final= dfmania[["participant_id", "answers_altman_sum", "Group"]]
(results_altman_final.head())

#AADIS שאלון 
dfaadispath = r'phenotype/adolescent_alcohol_and_drug_involvement_scale.tsv'
dfaadis = pd.read_csv(dfaadispath, delimiter="\t")
(dfaadis.head())# Display the first few rows

answers_aadis= ["aadis_q1", "aadis_q2", "aadis_q3", "aadis_q4", "aadis_q5", "aadis_q6", "aadis_q7", "aadis_q8",
                "aadis_q9", "aadis_q10", "aadis_q11", "aadis_q12", "aadis_q13"]
dfaadis[answers_aadis] = dfaadis[answers_aadis].apply(pd.to_numeric, errors="coerce")
dfaadis["Answers_aadis_sum"] = dfaadis[answers_aadis].sum(axis=1)
aadis_sum= dfaadis[["participant_id", "Answers_aadis_sum"]]
#i want it pretty dammit
(aadis_sum.head())

dfaadis["Group"] = dfaadis["Answers_aadis_sum"].apply(
    lambda x: "Non-Clinical" if x < 1 else
              "Clinical" if 1 <= x < 37 else  # noqa: PLR2004
              "Clinical")
grouped_aadis = dfaadis.groupby("Group")["Answers_aadis_sum"].agg(["count", "mean", "std"])
(grouped_aadis)

Final_table_aadis= dfaadis[["participant_id", "Answers_aadis_sum", "Group"]]
(Final_table_aadis.head())

drug_use = dfaadis.groupby("participant_id")["Answers_aadis_sum"].mean()
# I wanna see it all nice and pretty.
plt.figure(figsize=(6, 3))
drug_use.plot(kind="bar", color="violet", edgecolor="black")
plt.title("Drug use distribution")
plt.xlabel("participant_id")
plt.ylabel("Answers_aadis_sum")
plt.xticks(rotation=45, ha="right")
plt.grid(axis="y")
plt.tight_layout()
plt.show()

#שאלון BECKS DEPRESSION 
dfbdipath = r'phenotype/becks_depression_inventory.tsv'
dfbdi = pd.read_csv(dfbdipath, sep='\t')
# Display the first few rows because omg is it long. <insert dirty joke>
(dfbdi.head())

answers_bdi= ["bdi_q1", "bdi_q2", "bdi_q3", "bdi_q4", "bdi_q5", "bdi_q6", "bdi_q7", "bdi_q8", "bdi_q9", "bdi_q10",
               "bdi_q11", "bdi_q12", "bdi_q13", "bdi_q14", "bdi_q15", "bdi_q16", "bdi_q17", "bdi_q18", "bdi_q19",
                 "bdi_q20", "bdi_q21"]
dfbdi[answers_bdi] = dfbdi[answers_bdi].fillna(0) #this is what fixed the na problem. puts 0 in case of na.
dfbdi = dfbdi.dropna(subset=answers_bdi)
dfbdi[answers_bdi] = dfbdi[answers_bdi].apply(pd.to_numeric, errors="coerce")
dfbdi["answers_bdi_sum"] = dfbdi[answers_bdi].sum(axis=1)
#the bdi is scored by a general sum and then broken up into four groups.
result_bdi_sum = dfbdi[["participant_id", "answers_bdi_sum"]]
(result_bdi_sum.head())

# Now I need to group into the four different depression based groups.
dfbdi["Group"] = dfbdi["answers_bdi_sum"].apply(
    lambda x: "Non-Clinical" if x < 13 else  # noqa: PLR2004
              "Non-Clinical" if 14 <= x < 19 else  # noqa: PLR2004
              "Clinical" if 20 <= x < 28 else  # noqa: PLR2004
              "Clinical")
grouped_bdi = dfbdi.groupby("Group")["answers_bdi_sum"].agg(["count", "mean", "std"])
(grouped_bdi)

# Now the final table with everything on it
Final_table_bdi= dfbdi[["participant_id", "answers_bdi_sum", "Group"]]
(Final_table_bdi.head())

depression_level = dfbdi.groupby("participant_id")["answers_bdi_sum"].mean().sort_index()
# I wanna see it all nice and pretty.
plt.figure(figsize=(6, 3))
depression_level.plot(kind="bar", color="magenta", edgecolor="red")
plt.title("Depression severity")
plt.xlabel("participant_id")
plt.ylabel("answers_bdi_sum")
plt.xticks(rotation=45, ha="right")
plt.grid(axis="y")
plt.tight_layout()
plt.show()

depression_level = dfbdi.groupby("participant_id")["answers_bdi_sum"].mean().sort_index()
# I wanna see it all nice and pretty.
plt.figure(figsize=(6, 3))
depression_level.plot(kind="line", color="magenta")
plt.title("Depression severity")
plt.xlabel("participant_id")
plt.ylabel("answers_bdi_sum")
plt.xticks(rotation=45, ha="right")
plt.grid(axis="y")
plt.tight_layout()
plt.show()

#BEHAVIORAL INHIBITION/ACTIVATION SCALE שאלון 
dfbisbaspath = r'phenotype/behavioral_inhibition_scale_behavioral_activation_scale.tsv'
dfbisbas = pd.read_csv(dfbisbaspath, sep='\t')
# Display the first few rows
(dfbisbas.head())

# questions 1 and 18 are reversed, the rest are summed as usual
# dfbisbas[positive_columns]  df[positive_columns].applymap(lambda x: 1 if x in [0, 1] else 0)
reverse_columns= ["bisbas_1", "bisbas_18"]
dfbisbas[reverse_columns] = dfbisbas[reverse_columns].applymap(lambda x: 5 - x )

all_answers_bisbas= ["bisbas_1", "bisbas_2", "bisbas_3", "bisbas_4", "bisbas_5", "bisbas_6", "bisbas_7", "bisbas_8",
                  "bisbas_9", "bisbas_10", "bisbas_11", "bisbas_12", "bisbas_13", "bisbas_14", "bisbas_15", "bisbas_16",
                  "bisbas_17", "bisbas_18", "bisbas_19", "bisbas_20"]

dfbisbas[all_answers_bisbas] = dfbisbas[all_answers_bisbas].fillna(0)
# This is what fixed the na problem. puts 0 in case of na.
dfbisbas = dfbisbas.dropna(subset=all_answers_bisbas)
dfbisbas[all_answers_bisbas] = dfbisbas[all_answers_bisbas].apply(pd.to_numeric, errors="coerce")
dfbisbas["all_answers_bisbas_sum"] = dfbisbas[all_answers_bisbas].sum(axis=1)

result_bisbas_sum = dfbisbas[["participant_id", "all_answers_bisbas_sum"]]

(result_bisbas_sum.head())

# Break into groups bisbas
bisbas_punishment_sensitivity_scale= ["bisbas_1", "bisbas_6", "bisbas_10", "bisbas_13", "bisbas_15", "bisbas_18",
                                       "bisbas_20"]
bisbas_reward_responsiveness= ["bisbas_3", "bisbas_5", "bisbas_11", "bisbas_14", "bisbas_19"]
bisbas_drive= ["bisbas_2", "bisbas_7", "bisbas_9", "bisbas_17"]
bisbas_fun_seeking= ["bisbas_4", "bisbas_8", "bisbas_12", "bisbas_16"]

#create the groups with sum
dfbisbas["Punishment_sensitivity_sum"]= dfbisbas[bisbas_punishment_sensitivity_scale].sum(axis=1)
dfbisbas["Reward_responsiveness_sum"]= dfbisbas[bisbas_reward_responsiveness].sum(axis=1)
dfbisbas["Bisbas_drive_sum"]= dfbisbas[bisbas_drive].sum(axis=1)
dfbisbas["fun_seeking_sum"]= dfbisbas[bisbas_fun_seeking].sum(axis=1)

Table_bisbas= dfbisbas[["participant_id", "Punishment_sensitivity_sum", "Reward_responsiveness_sum", "Bisbas_drive_sum",
                         "fun_seeking_sum"]]
(Table_bisbas.head())

# I'm going to try and group these fuckers so that i can see in which group there is more
(dfbisbas[["Punishment_sensitivity_sum", "Reward_responsiveness_sum", "Bisbas_drive_sum",
            "fun_seeking_sum"]].describe().T)

# I'm gonna create groups.
dfbisbas["bisbas_punishment_group"] = dfbisbas["Punishment_sensitivity_sum"].apply(
    lambda x: "Low punishment sensitivity" if x < 20 else "High punishment sensitivity")  # noqa: PLR2004 # It's snitching.
grouped_punishment_bisbas= dfbisbas.groupby("bisbas_punishment_group")["Punishment_sensitivity_sum"].agg(
    ["count", "mean", "std"])
(grouped_punishment_bisbas)

# Gonna create a group for reward kink bitches.
dfbisbas["bisbas_reward_group"] = dfbisbas["Reward_responsiveness_sum"].apply(
    lambda x: "Low reward responsiveness" if x < 17 else "High reward responsiveness")  # noqa: PLR2004
grouped_reward_bisbas= dfbisbas.groupby("bisbas_reward_group")["Reward_responsiveness_sum"].agg(
    ["count", "mean", "std"])
(grouped_reward_bisbas)

# Drive group.
dfbisbas["bisbas_drive_group"] = dfbisbas["Bisbas_drive_sum"].apply(lambda x: "Low drive" if x < 11 else "High drive")  # noqa: PLR2004
grouped_drive_bisbas= dfbisbas.groupby("bisbas_drive_group")["Bisbas_drive_sum"].agg(["count", "mean", "std"])
(grouped_drive_bisbas)

# Fun seeking
dfbisbas["bisbas_fun_seeking_group"] = dfbisbas["fun_seeking_sum"].apply(
    lambda x: "Low fun seeking" if x < 12 else "High fun seeking")  # noqa: PLR2004
grouped_fun_seeking_bisbas= dfbisbas.groupby("bisbas_fun_seeking_group")["fun_seeking_sum"].agg(
    ["count", "mean", "std"])
(grouped_fun_seeking_bisbas)

Final_table_bisbas= dfbisbas[["participant_id", "bisbas_fun_seeking_group", "bisbas_drive_group", "bisbas_reward_group",
                               "bisbas_punishment_group"]]
(Final_table_bisbas.head())

#BUSS PERRY AGRESSION שאלון 
dfbpaqpath = r'phenotype/buss_perry_aggression_questionnaire.tsv'
dfbpaq = pd.read_csv(dfbpaqpath, sep='\t')
# Display the first few rows
(dfbpaq.head())

# 7 and 18 are reverse scored dfbisbas[reverse_columns] = dfbisbas[reverse_columns].applymap(lambda x: 5 - x )
reverse_score_bpaq= ["bpaq_q7", "bpaq_q18"]
dfbpaq[reverse_score_bpaq].map(lambda x: 6 - x)
bpaq_answers= ["bpaq_q1", "bpaq_q2", "bpaq_q3", "bpaq_q4", "bpaq_q5", "bpaq_q6", "bpaq_q7", "bpaq_q8", "bpaq_q9",
               "bpaq_q10", "bpaq_q11", "bpaq_q12", "bpaq_q13", "bpaq_q14", "bpaq_q15", "bpaq_q16", "bpaq_q17",
                 "bpaq_q18", "bpaq_q19", "bpaq_q20", "bpaq_q21", "bpaq_q22", "bpaq_q23", "bpaq_q24", "bpaq_q25",
                 "bpaq_q26", "bpaq_q27", "bpaq_q28", "bpaq_q29"]

dfbpaq[bpaq_answers] = dfbpaq[bpaq_answers].fillna(0)
# This is what fixed the na problem.
dfbpaq = dfbpaq.dropna(subset=bpaq_answers)
dfbpaq[bpaq_answers] = dfbpaq[bpaq_answers].map(pd.to_numeric, errors="coerce")
dfbpaq["bpaq_answers_sum"] = dfbpaq[bpaq_answers].sum(axis=1)

result_bpaq_sum = dfbpaq[["participant_id", "bpaq_answers_sum"]]

(result_bpaq_sum.head())

# Grouping time! agression levels is a go!
dfbpaq["Group"] = dfbpaq["bpaq_answers_sum"].apply( lambda x: "Non-Clinical" if x < 64.9 else  # noqa: PLR2004
                                                         "Clinical" if 65 <= x < 95 else  # noqa: PLR2004
                                                         "Clinical")
grouped_bpaq= dfbpaq.groupby("Group")["bpaq_answers_sum"].agg(["count", "mean", "median", "std"])
(grouped_bpaq)

Final_table_bpaq= dfbpaq[["participant_id", "bpaq_answers_sum", "Group"]]
(Final_table_bpaq.head())

Agression_level = dfbpaq.groupby("participant_id")["bpaq_answers_sum"].mean().sort_index()
# I wanna see it all nice and pretty.
plt.figure(figsize=(10, 5))
Agression_level.plot(kind="bar", color="yellow", edgecolor="purple")
plt.title("Agression severity")
plt.xlabel("participant_id")
plt.ylabel("bpaq_answers_sum")
plt.xticks(rotation=45, ha="right")
plt.grid(axis="y")
plt.tight_layout()
plt.show()

Agression_level = dfbpaq.groupby("participant_id")["bpaq_answers_sum"].mean().sort_index()
# I wanna see it all nice and pretty.
plt.figure(figsize=(9, 4))
Agression_level.plot(kind="density", color="orange")
plt.title("Agression severity")
plt.xlabel("bpaq_answers_sum")
plt.ylabel("participant_id")
plt.xticks(rotation=45, ha="right")
plt.grid(axis="y")
plt.tight_layout()
plt.show()

#שאלון CHILDHOOD TRAUMA
dfctqsfpath = r'phenotype/childhood_trauma_questionnaire_short_form.tsv'
dfctqsf = pd.read_csv(dfctqsfpath, sep='\t')
# Display the first few rows
(dfctqsf.head())

reverse_columns= ["ctqsf_adult_cj_2"]
dfctqsf[reverse_columns] = dfctqsf[reverse_columns].map(lambda x: 6 - x )

denial_dcolumns= ["ctqsf_adult_cj_10", "ctqsf_adult_cj_16", "ctqsf_adult_cj_22"]
dfctqsf[denial_dcolumns]= dfctqsf [denial_dcolumns].map(lambda x: 1 if x== 5 else 0)  # noqa: PLR2004
dfctqsf["denial_dcolumns_sum"]= dfctqsf[denial_dcolumns].sum(axis=1)
# I reversed the questions that for some reason hadn't been reversed in advanced that we're certainly reverse versed.

all_answers_ctqsf= ["ctqsf_adult_cj_1", "ctqsf_adult_cj_2", "ctqsf_adult_cj_3", "ctqsf_adult_cj_4", "ctqsf_adult_cj_5",
                      "ctqsf_adult_cj_6", "ctqsf_adult_cj_7","ctqsf_adult_cj_8","ctqsf_adult_cj_9",
                        "ctqsf_adult_cj_11", "ctqsf_adult_cj_12", "ctqsf_adult_cj_13","ctqsf_adult_cj_14",
                          "ctqsf_adult_cj_15", "ctqsf_adult_cj_17","ctqsf_adult_cj_18", "ctqsf_adult_cj_19",
                            "ctqsf_adult_cj_20", "ctqsf_adult_cj_21", "ctqsf_adult_cj_23", "ctqsf_adult_cj_24",
                             "ctqsf_adult_cj_25", "ctqsf_adult_cj_26", "ctqsf_adult_cj_27", "ctqsf_adult_cj_28"]

dfctqsf[all_answers_ctqsf] = dfctqsf[all_answers_ctqsf].fillna(0)
# This is what fixed the na problem. puts 0 in case of na.
dfctqsf = dfctqsf.dropna(subset=all_answers_ctqsf)
dfctqsf[all_answers_ctqsf] = dfctqsf[all_answers_ctqsf].apply(pd.to_numeric, errors="coerce")
dfctqsf["all_answers_ctqsf_sum"] = dfctqsf[all_answers_ctqsf].sum(axis=1)

result_ctqsf_sum = dfctqsf[["participant_id", "all_answers_ctqsf_sum", "denial_dcolumns_sum"]]

(result_ctqsf_sum.head())

# Emotional abuse: 3, 8, 14, 18, 25.
# Pysical abuse: 9, 11, 12, 15, 17.
# Sexual abuse: 20, 21, 23, 24, 27.
# Emotional neglect: 5, 7, 13, 19, 28.
# Physical neglect: 1, 2, 4, 6, 26.

# Break down into abuse columns.
# Emotional abuse: 3, 8, 14, 18, 25.
emotional_abuse= ["ctqsf_adult_cj_3", "ctqsf_adult_cj_8", "ctqsf_adult_cj_14", "ctqsf_adult_cj_18", "ctqsf_adult_cj_25"]
dfctqsf[emotional_abuse]= dfctqsf[emotional_abuse].fillna(0)
dfctqsf = dfctqsf.dropna(subset=emotional_abuse)
dfctqsf["Emotional_abuse_sum"] = dfctqsf[emotional_abuse].sum(axis=1)
# Pysical abuse: 9, 11, 12, 15, 17.
physical_abuse= ["ctqsf_adult_cj_9", "ctqsf_adult_cj_11", "ctqsf_adult_cj_12", "ctqsf_adult_cj_15", "ctqsf_adult_cj_17"]
dfctqsf[physical_abuse]= dfctqsf[physical_abuse].fillna(0)
dfctqsf = dfctqsf.dropna(subset=physical_abuse)
dfctqsf["Physical_abuse_sum"] = dfctqsf[physical_abuse].sum(axis=1)
# Sexual abuse: 20, 21, 23, 24, 27.
sexual_abuse= ["ctqsf_adult_cj_20", "ctqsf_adult_cj_21", "ctqsf_adult_cj_23", "ctqsf_adult_cj_24", "ctqsf_adult_cj_27"]
dfctqsf[sexual_abuse]= dfctqsf[sexual_abuse].fillna(0)
dfctqsf = dfctqsf.dropna(subset=sexual_abuse)
dfctqsf["Sexual_abuse_sum"] = dfctqsf[sexual_abuse].sum(axis=1)
# Emotional neglect: 5, 7, 13, 19, 28.
emotional_neglect= ["ctqsf_adult_cj_5", "ctqsf_adult_cj_7", "ctqsf_adult_cj_13", "ctqsf_adult_cj_19",
                    "ctqsf_adult_cj_28"]
dfctqsf[emotional_neglect]= dfctqsf[emotional_neglect].fillna(0)
dfctqsf = dfctqsf.dropna(subset=emotional_neglect)
dfctqsf["Emotional_neglect_sum"] = dfctqsf[emotional_neglect].sum(axis=1)
# Physical neglect: 1, 2, 4, 6, 26.
physical_neglect= ["ctqsf_adult_cj_1", "ctqsf_adult_cj_2", "ctqsf_adult_cj_4", "ctqsf_adult_cj_6", "ctqsf_adult_cj_26"]
dfctqsf[physical_neglect]= dfctqsf[physical_neglect].fillna(0)
dfctqsf = dfctqsf.dropna(subset=physical_neglect)
dfctqsf["Physical_neglect_sum"] = dfctqsf[physical_neglect].sum(axis=1)

Childhood_trauma_m_ctqsf= dfctqsf[["participant_id", "Emotional_abuse_sum", "Physical_abuse_sum", "Sexual_abuse_sum",
                        "Emotional_neglect_sum", "Physical_neglect_sum", "denial_dcolumns_sum"]]
(Childhood_trauma_m_ctqsf.head())

# Emotional abuse
dfctqsf["Group"] = dfctqsf["Emotional_abuse_sum"].apply( lambda x: "Clinical" if x >= 13 else  # noqa: PLR2004
                                                         "Non-Clinical")
grouped_emotional_abuse= dfctqsf.groupby("Group")["Emotional_abuse_sum"].agg(["count", "mean",
                                                                                                "median", "std"])
(grouped_emotional_abuse)

# Sexual abuse
dfctqsf["Group"] = dfctqsf["Sexual_abuse_sum"].apply( lambda x: "Clinical" if x >= 8 else  # noqa: PLR2004
                                                         "Non-Clinical")
grouped_sexual_abuse= dfctqsf.groupby("Group")["Sexual_abuse_sum"].agg(["count", "mean",
                                                                                                "median", "std"])
(grouped_sexual_abuse)

# Physical abuse
dfctqsf["Group"] = dfctqsf["Physical_abuse_sum"].apply( lambda x: "Clinical" if x >= 10 else  # noqa: PLR2004
                                                         "Non-Clinical")
grouped_physical_abuse= dfctqsf.groupby("Group")["Physical_abuse_sum"].agg(["count", "mean",
                                                                                                "median", "std"])
(grouped_physical_abuse)

# Emotional neglect
dfctqsf["Group"] = dfctqsf["Emotional_neglect_sum"].apply(
    lambda x: "Clinical" if x >= 15 else "Non-Clinical") # noqa: PLR2004
grouped_emotional_neglect= dfctqsf.groupby("Group")["Emotional_neglect_sum"].agg(["count", "mean",
                                                                                                "median", "std"])
(grouped_emotional_neglect)

# Physical neglect
dfctqsf["Group"] = dfctqsf["Physical_neglect_sum"].apply(
    lambda x: "Clinical" if x >= 10 else "Non-Clinical")# noqa: PLR2004
grouped_physical_neglect= dfctqsf.groupby("Group")["Physical_neglect_sum"].agg(["count", "mean",
                                                                                                "median", "std"])
(grouped_physical_neglect)

# I wanna combine all catagories and then group based off of abuse/neglect.
Ctqsf_clinical_nonclinical= dfctqsf[["participant_id", "Group"]]
(Ctqsf_clinical_nonclinical.head())

#DRUG USE DISORDER שאלון 
dfduditfpath = r'phenotype/drug_use_disorders_identification_test.tsv'
dfdudit = pd.read_csv(dfduditfpath, sep='\t')
# Display the first few rows
(dfdudit.head())

dudit_answers= ["dudit_1", "dudit_2", "dudit_3", "dudit_4", "dudit_5", "dudit_6", "dudit_7", "dudit_8", "dudit_9",
                 "dudit_10", "dudit_11"]
dfdudit[dudit_answers]= dfdudit[dudit_answers].fillna(0)
dfdudit = dfdudit.dropna(subset=dudit_answers)
dfdudit[dudit_answers] = dfdudit[dudit_answers].apply(pd.to_numeric, errors="coerce")
dfdudit["dudit_answers_sum"] = dfdudit[dudit_answers].sum(axis=1)

result_dudit_sum = dfdudit[["participant_id", "dudit_answers_sum"]]

(result_dudit_sum.head())

dfdudit["Group"] = dfdudit["dudit_answers_sum"].apply(
    lambda x: "Clinical" if x >= 25 else "Non-Clinical")# noqa: PLR2004
grouped_drug_dependance= dfdudit.groupby("Group")["dudit_answers_sum"].agg(["count", "mean","median", "std"])
(grouped_drug_dependance)

Drug_dependancy_table= dfdudit[["participant_id", "Group", "dudit_answers_sum"]]
(Drug_dependancy_table.head())

#personal norms of reciprocity שאלון 
dfpnrfpath = r'phenotype/personal_norms_of_reciprocity.tsv'
dfpnr = pd.read_csv(dfpnrfpath, sep='\t')
# Display the first few rows
(dfpnr.head())

# All questions comprise of negative reciprocity subscale. simple sum.
pnr_questions= ["pnr_q1", "pnr_q2", "pnr_q3", "pnr_q4", "pnr_q5", "pnr_q6", "pnr_q7", "pnr_q8", "pnr_q9"]
dfpnr[pnr_questions]= dfpnr[pnr_questions].fillna(0)
dfpnr = dfpnr.dropna(subset=pnr_questions)
dfpnr[pnr_questions] = dfpnr[pnr_questions].apply(pd.to_numeric, errors="coerce")
dfpnr["pnr_answers_sum"] = dfpnr[pnr_questions].sum(axis=1)

result_pnr_sum = dfpnr[["participant_id", "pnr_answers_sum"]]

(result_pnr_sum.head())

(dfpnr["pnr_answers_sum"].mean())

dfpnr["Group"] = dfpnr["pnr_answers_sum"].apply(
    lambda x: "Clinical" if x >= 21 else "Non-Clinical")# noqa: PLR2004
grouped_negative_r= dfpnr.groupby("Group")["pnr_answers_sum"].agg(["count", "mean","median", "std"])
(grouped_negative_r)

Reciprocity_table= dfpnr[["participant_id", "Group", "pnr_answers_sum"]]
(Reciprocity_table.head())

#positive valence system survey שאלון 
dfpvssfpath = r'phenotype/positive_valence_systems_survey.tsv'
dfpvss = pd.read_csv(dfpvssfpath, sep='\t')
# Display the first few rows
(dfpvss.head())

# The questions all appear to be reverse scored. the lower the score, the higher the depression.
pvss_questions= ["pvss_q1", "pvss_q2", "pvss_q3", "pvss_q4", "pvss_q5", "pvss_q6", "pvss_q7", "pvss_q8", "pvss_q9",
                  "pvss_q10", "pvss_q11", "pvss_q12", "pvss_q13", "pvss_q14", "pvss_q15", "pvss_q16", "pvss_q17",
                    "pvss_q18", "pvss_q19", "pvss_q20", "pvss_q21"]
dfpvss[pvss_questions] = dfpvss[pvss_questions].map(lambda x: 10 - x )
dfpvss[pvss_questions]= dfpvss[pvss_questions].fillna(0)
dfpvss = dfpvss.dropna(subset=pvss_questions)
dfpvss[pvss_questions] = dfpvss[pvss_questions].apply(pd.to_numeric, errors="coerce")
dfpvss["pvss_answers_sum"] = dfpvss[pvss_questions].sum(axis=1)

result_pvss_sum = dfpvss[["participant_id", "pvss_answers_sum"]]

(result_pvss_sum.head())

(dfpvss["pvss_answers_sum"].mean())

# group by clinical non clinical.
dfpvss["Group"] = dfpvss["pvss_answers_sum"].apply(
    lambda x: "Clinical" if x >= 86 else "Non-Clinical")# noqa: PLR2004
grouped_pvss= dfpvss.groupby("Group")["pvss_answers_sum"].agg(["count", "mean","median", "std"])
(grouped_pvss)

Pvss_table= dfpvss[["participant_id", "Group", "pvss_answers_sum"]]
(Pvss_table.head())

#שאלון unpredictability in childhood
dfquicfpath = r'phenotype/questionnaire_of_unpredictability_in_childhood.tsv'
dfquic = pd.read_csv(dfquicfpath, sep='\t')
# Display the first few rows
(dfquic.head())

reverse_columns_quic= ["quic_adult_cj_1", "quic_adult_cj_2", "quic_adult_cj_3", "quic_adult_cj_4", "quic_adult_cj_5",
                        "quic_adult_cj_6", "quic_adult_cj_7", "quic_adult_cj_9", "quic_adult_cj_10", "quic_adult_cj_14",
                          "quic_adult_cj_8", "quic_adult_cj_15", "quic_adult_cj_17", "quic_adult_cj_28",
                            "quic_adult_cj_36"]
dfquic[reverse_columns_quic] = dfquic[reverse_columns_quic].map(lambda x: 1 - x )
quic_questions= ["quic_adult_cj_1", "quic_adult_cj_2", "quic_adult_cj_3", "quic_adult_cj_4", "quic_adult_cj_5",
                  "quic_adult_cj_6", "quic_adult_cj_7", "quic_adult_cj_8", "quic_adult_cj_9", "quic_adult_cj_10",
                    "quic_adult_cj_11", "quic_adult_cj_12", "quic_adult_cj_13", "quic_adult_cj_14", "quic_adult_cj_15",
                    "quic_adult_cj_16", "quic_adult_cj_17", "quic_adult_cj_18", "quic_adult_cj_19", "quic_adult_cj_20",
                    "quic_adult_cj_21", "quic_adult_cj_22", "quic_adult_cj_23", "quic_adult_cj_24", "quic_adult_cj_25",
                      "quic_adult_cj_26", "quic_adult_cj_27", "quic_adult_cj_28", "quic_adult_cj_29", "quic_adult_cj_30"
                      ,"quic_adult_cj_31", "quic_adult_cj_32", "quic_adult_cj_33", "quic_adult_cj_34",
                        "quic_adult_cj_35", "quic_adult_cj_36", "quic_adult_cj_37", "quic_adult_cj_38"]
dfquic[quic_questions]= dfquic[quic_questions].fillna(0)
dfquic = dfquic.dropna(subset=quic_questions)
dfquic[quic_questions] = dfquic[quic_questions].apply(pd.to_numeric, errors="coerce")
dfquic["quic_answers_sum"] = dfquic[quic_questions].sum(axis=1)

result_quic_sum = dfquic[["participant_id", "quic_answers_sum"]]

(result_quic_sum.head())

(dfquic["quic_answers_sum"].mean())

dfquic["Group"] = dfquic["quic_answers_sum"].apply(
    lambda x: "Clinical" if x >= 6 else "Non-Clinical")# noqa: PLR2004
grouped_quic= dfquic.groupby("Group")["quic_answers_sum"].agg(["count", "mean","median", "std"])
(grouped_quic)

#R. self esteem שאלון 
dfrsefpath = r'phenotype/rosenberg_self_esteem.tsv'
dfrse = pd.read_csv(dfrsefpath, sep='\t')
# Display the first few rows
(dfrse.head())

# Question scale is from 0-3 in the origional version, but it says that it can be done 1-4.
# scale will range from 1-40, 40 being the highest score, as in very high self esteem.
# Reverse items are- 1,2,4,6,7
# non reverse: 3,5,8,9,10

reverse_r_score= ["rse_q1", "rse_q2", "rse_q4", "rse_q6", "rse_q7"]
dfrse[reverse_r_score] = dfrse[reverse_r_score].map(lambda x: 5 - x )

R_self_esteem_questions= ["rse_q1", "rse_q2", "rse_q3", "rse_q4", "rse_q5", "rse_q6", "rse_q7", "rse_q8",
                           "rse_q9", "rse_q10"]

dfrse[R_self_esteem_questions]= dfrse[R_self_esteem_questions].fillna(0)
dfrse = dfrse.dropna(subset=R_self_esteem_questions)
dfrse[R_self_esteem_questions] = dfrse[R_self_esteem_questions].apply(pd.to_numeric, errors="coerce")
dfrse["R_self_esteem_sum"] = dfrse[R_self_esteem_questions].sum(axis=1)

result_rse_sum = dfrse[["participant_id", "R_self_esteem_sum"]]

(result_rse_sum.head())

# Check mean so that i know how to divide the groups.
(dfrse["R_self_esteem_sum"].mean())

# Group by high and low self esteem.
dfrse["Group"] = dfrse["R_self_esteem_sum"].apply(
    lambda x: "Non-Clinical" if x >= 26 else "Clinical")# noqa: PLR2004
grouped_rse= dfrse.groupby("Group")["R_self_esteem_sum"].agg(["count", "mean","median", "std"])
(grouped_rse)

Rse_final_table= dfrse[["participant_id", "Group", "R_self_esteem_sum"]]
(Rse_final_table.head())
#sensitivity to punishment/reward שאלון 

dfspsrqfpath = r'phenotype/sensitivity_to_punishment_sensitivity_to_reward_questionnaire.tsv'
dfspsrq = pd.read_csv(dfspsrqfpath, sep='\t')
# Display the first few rows
(dfspsrq.head())

#Punishment (1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45,47)  # noqa: ERA001
Punishment_spsrq_q= ["spsrq_1", "spsrq_3", "spsrq_5", "spsrq_7", "spsrq_9", "spsrq_11", "spsrq_13", "spsrq_15",
                     "spsrq_17", "spsrq_19", "spsrq_21", "spsrq_23", "spsrq_25", "spsrq_27","spsrq_29",
                      "spsrq_31", "spsrq_33", "spsrq_35", "spsrq_37", "spsrq_39", "spsrq_41", "spsrq_43",
                       "spsrq_45", "spsrq_47"]

dfspsrq[Punishment_spsrq_q]= dfspsrq[Punishment_spsrq_q].fillna(0)
dfspsrq = dfspsrq.dropna(subset=Punishment_spsrq_q)
dfspsrq[Punishment_spsrq_q] = dfspsrq[Punishment_spsrq_q].apply(pd.to_numeric, errors="coerce")
dfspsrq["Punishment_spsrq_sum"] = dfspsrq[Punishment_spsrq_q].sum(axis=1)

result_punishment_spsrq_sum = dfspsrq [["participant_id", "Punishment_spsrq_sum"]]

(result_punishment_spsrq_sum.head())

(dfspsrq["Punishment_spsrq_sum"].mean())

# divide groups by mean.
dfspsrq["Punishment_spsrq_groups"] = dfspsrq["Punishment_spsrq_sum"].apply(
    lambda x: "High punishment sensitivity" if x >= 14 else "Low punishment sensitivity")# noqa: PLR2004
grouped_punishment_spsrq= dfspsrq.groupby("Punishment_spsrq_groups")["Punishment_spsrq_sum"].agg(["count", "mean",
                                                                                                  "median", "std"])
(grouped_punishment_spsrq)

# Reward (2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46, 48)  # noqa: ERA001
Reward_spsrq_q= ["spsrq_2", "spsrq_4", "spsrq_6", "spsrq_8", "spsrq_10", "spsrq_12", "spsrq_14", "spsrq_16",
                     "spsrq_18", "spsrq_20", "spsrq_22", "spsrq_24", "spsrq_26", "spsrq_28","spsrq_30",
                      "spsrq_32", "spsrq_34", "spsrq_36", "spsrq_38", "spsrq_40", "spsrq_42", "spsrq_44",
                       "spsrq_46", "spsrq_48"]

dfspsrq[Reward_spsrq_q]= dfspsrq[Reward_spsrq_q].fillna(0)
dfspsrq = dfspsrq.dropna(subset=Reward_spsrq_q)
dfspsrq[Reward_spsrq_q] = dfspsrq[Reward_spsrq_q].apply(pd.to_numeric, errors="coerce")
dfspsrq["Reward_spsrq_sum"] = dfspsrq[Reward_spsrq_q].sum(axis=1)

result_reward_spsrq_sum = dfspsrq [["participant_id", "Reward_spsrq_sum"]]

(result_reward_spsrq_sum.head())

(dfspsrq["Reward_spsrq_sum"].mean())

# divide groups by mean.
dfspsrq["Reward_spsrq_groups"] = dfspsrq["Reward_spsrq_sum"].apply(
    lambda x: "High Reward sensitivity" if x >= 12.2 else "Low Reward sensitivity")# noqa: PLR2004
grouped_reward_spsrq= dfspsrq.groupby("Reward_spsrq_groups")["Reward_spsrq_sum"].agg(["count", "mean",
                                                                                                  "median", "std"])
(grouped_reward_spsrq)

# final spsrq table.
Spsrq_final_table= dfspsrq[["participant_id", "Reward_spsrq_groups", "Reward_spsrq_sum", "Punishment_spsrq_groups",
                             "Punishment_spsrq_sum"]]
(Spsrq_final_table.head())

#שאלון seven up/down
dfsusdpath = r'phenotype/seven_up_seven_down.tsv'
dfsusd = pd.read_csv(dfsusdpath, sep='\t')
# Display the first few rows
(dfsusd.head())

# Mania q: 1,3,4,6,7,8,13
# Depression q: 2,5,9,10,11,12,14

# Mania q: 1,3,4,6,7,8,13
Mania_questions_susd= ["score_susd_q1", "score_susd_q3", "score_susd_q4", "score_susd_q6", "score_susd_q7",
                        "score_susd_q8", "score_susd_q13"]
dfsusd[Mania_questions_susd]= dfsusd[Mania_questions_susd].fillna(0)
dfsusd = dfsusd.dropna(subset=Mania_questions_susd)
dfsusd[Mania_questions_susd] = dfsusd[Mania_questions_susd].apply(pd.to_numeric, errors="coerce")
dfsusd["susd_mania_sum"] = dfsusd[Mania_questions_susd].sum(axis=1)

result_susd_mania_sum = dfsusd[["participant_id", "susd_mania_sum"]]

(result_susd_mania_sum.head())

(dfsusd["susd_mania_sum"].mean())

# Create mania groups based off of mean.
dfsusd["Group"] = dfsusd["susd_mania_sum"].apply(
    lambda x: "Clinical" if x >= 3.7 else "Non-Clinical")# noqa: PLR2004
grouped_mania_susd= dfsusd.groupby("Group")["susd_mania_sum"].agg(["count", "mean","median", "std"])
(grouped_mania_susd)

# Depression q: 2,5,9,10,11,12,14
Depression_questions_susd= ["score_susd_q2", "score_susd_q5", "score_susd_q9", "score_susd_q10", "score_susd_q11",
                        "score_susd_q12", "score_susd_q14"]
dfsusd[Depression_questions_susd]= dfsusd[Depression_questions_susd].fillna(0)
dfsusd = dfsusd.dropna(subset=Depression_questions_susd)
dfsusd[Depression_questions_susd] = dfsusd[Depression_questions_susd].apply(pd.to_numeric, errors="coerce")
dfsusd["susd_depression_sum"] = dfsusd[Depression_questions_susd].sum(axis=1)

result_susd_depression_sum = dfsusd[["participant_id", "susd_depression_sum"]]

(result_susd_depression_sum.head())

(dfsusd["susd_depression_sum"].mean())

dfsusd["Group"] = dfsusd["susd_depression_sum"].apply(
    lambda x: "Clinical" if x >= 4.3 else "Non-Clinical")# noqa: PLR2004
grouped_depression_susd= dfsusd.groupby("Group")["susd_depression_sum"].agg(["count", "mean","median",
                                                                                               "std"])
(grouped_depression_susd)

# Final table
Susd_final_table= dfsusd[["participant_id", "Group", "susd_depression_sum",
                           "Group", "susd_mania_sum"]]
(Susd_final_table.head())

# I want to see a total score for a minute
all_susd_questions= ["score_susd_q1", "score_susd_q3", "score_susd_q4", "score_susd_q6", "score_susd_q7",
                        "score_susd_q8", "score_susd_q13", "score_susd_q2", "score_susd_q5", "score_susd_q9",
                          "score_susd_q10", "score_susd_q11", "score_susd_q12", "score_susd_q14"]
dfsusd[all_susd_questions]= dfsusd[all_susd_questions].fillna(0)
dfsusd = dfsusd.dropna(subset=all_susd_questions)
dfsusd[all_susd_questions] = dfsusd[all_susd_questions].apply(pd.to_numeric, errors="coerce")
dfsusd["susd_sum"] = dfsusd[all_susd_questions].sum(axis=1)

result_susd_sum = dfsusd[["participant_id", "susd_sum"]]

(result_susd_sum.head())

Susd_final_table2= dfsusd[["participant_id", "Group", "susd_depression_sum",
                            "Group", "susd_mania_sum", "susd_sum"]]
(Susd_final_table2.head())

#social experience questionnaire שאלון 
dfseqpath = r'phenotype/social_experience_questionnaire.tsv'
dfseq = pd.read_csv(dfseqpath, sep='\t')
# Display the first few rows
(dfseq.head())

# seems to revolve around bullying
# Reverse questions: 1, 5, 8, 12, 15
# scale of 1-5, so ill do lambda 6-x.

reverse_seq_questions= ["seq_adult_cj_1", "seq_adult_cj_5", "seq_adult_cj_8", "seq_adult_cj_12", "seq_adult_cj_15"]
dfseq[reverse_seq_questions] = dfseq[reverse_seq_questions].map(lambda x: 6 - x )

seq_questions= ["seq_adult_cj_1", "seq_adult_cj_2", "seq_adult_cj_3", "seq_adult_cj_4", "seq_adult_cj_5",
                         "seq_adult_cj_6", "seq_adult_cj_7", "seq_adult_cj_8", "seq_adult_cj_9", "seq_adult_cj_10",
                         "seq_adult_cj_11", "seq_adult_cj_12", "seq_adult_cj_13", "seq_adult_cj_14", "seq_adult_cj_15"]
dfseq[seq_questions]= dfseq[seq_questions].fillna(0)
dfseq = dfseq.dropna(subset=seq_questions)
dfseq[seq_questions] = dfseq[seq_questions].apply(pd.to_numeric, errors="coerce")
dfseq["seq_questions_sum"] = dfseq[seq_questions].sum(axis=1)

result_seq_sum = dfseq[["participant_id", "seq_questions_sum"]]

(result_seq_sum.head())

(dfseq["seq_questions_sum"].mean())

# I will group based off of mean.
dfseq["Group"] = dfseq["seq_questions_sum"].apply(
    lambda x: "Clinical" if x >= 17 else "Non-Clinical")# noqa: PLR2004
grouped_seq= dfseq.groupby("Group")["seq_questions_sum"].agg(["count", "mean","median", "std"])
(grouped_seq)

Seq_final_table= dfseq[["participant_id", "Group", "seq_questions_sum"]]
(Seq_final_table.head())

#temporal experience of pleasure שאלון 
dftepspath = r'phenotype/temporal_experience_of_pleasure_scale.tsv'
dfteps = pd.read_csv(dftepspath, sep='\t')
# Display the first few rows
(dfteps.head())

#The anticipatory pleasure factor captures the future-oriented pleasure, while the consummatory pleasure factor captures
#-in-the-moment pleasure
#A lower score indicates a higher anhedonia propensity
#anahdonia an apathy for a lack.

#anticipatory factor; 1,4,6,8,10,11,13R,15,16,18
#consumatory experiences; 2,3,5,7,9,12,14,17
# 6 point scale. 1-very false, 6-very true.

reverse_an13= ["score_teps_q13"]
dfteps[reverse_an13] = dfteps[reverse_an13].map(lambda x: 7 - x )

teps_all_questions= ["score_teps_q1", "score_teps_q2", "score_teps_q3", "score_teps_q4", "score_teps_q5",
                      "score_teps_q6", "score_teps_q7", "score_teps_q8", "score_teps_q9", "score_teps_q10",
                       "score_teps_q11", "score_teps_q12", "score_teps_q13", "score_teps_q14", "score_teps_q15"
                       ,"score_teps_q16", "score_teps_q17", "score_teps_q18"]
dfteps[teps_all_questions]= dfteps[teps_all_questions].fillna(0)
dfteps = dfteps.dropna(subset=teps_all_questions)
dfteps[teps_all_questions] = dfteps[teps_all_questions].apply(pd.to_numeric, errors="coerce")
dfteps["Teps_questions_sum"] = dfteps[teps_all_questions].sum(axis=1)

result_teps_sum = dfteps[["participant_id", "Teps_questions_sum"]]

(result_teps_sum.head())

(dfteps["Teps_questions_sum"].mean())

# general groups
dfteps["Group"] = dfteps["Teps_questions_sum"].apply(
    lambda x: "Non-Clinical" if x >= 79 else "Clinical")# noqa: PLR2004
grouped_teps_general= dfteps.groupby("Group")["Teps_questions_sum"].agg(["count", "mean",
                                                                                                "median", "std"])
(grouped_teps_general)

#anticipatory factor; 1,4,6,8,10,11,13R,15,16,18
teps_anticipatory_questions= ["score_teps_q1","score_teps_q4","score_teps_q6","score_teps_q8","score_teps_q10",
                              "score_teps_q11","score_teps_q13","score_teps_q15","score_teps_q16", "score_teps_q18"]
dfteps[teps_anticipatory_questions]= dfteps[teps_anticipatory_questions].fillna(0)
dfteps = dfteps.dropna(subset=teps_anticipatory_questions)
dfteps[teps_anticipatory_questions] = dfteps[teps_anticipatory_questions].apply(pd.to_numeric, errors="coerce")
dfteps["Teps_anticipatory_sum"] = dfteps[teps_anticipatory_questions].sum(axis=1)

result_anticipatory_sum = dfteps[["participant_id", "Teps_anticipatory_sum"]]

(result_anticipatory_sum.head())

(dfteps["Teps_anticipatory_sum"].mean())

#anticipatory groups
dfteps["Group"] = dfteps["Teps_anticipatory_sum"].apply(
    lambda x: "Non-Clinical" if x >= 42 else "Clinical")# noqa: PLR2004
grouped_teps_anticipatory= dfteps.groupby("Group")["Teps_anticipatory_sum"].agg(["count",
                                                                                                             "mean",
                                                                                                             "median",
                                                                                                             "std"])
(grouped_teps_anticipatory)

#consumatory experiences; 2,3,5,7,9,12,14,17
teps_consumatory_questions= ["score_teps_q2", "score_teps_q3", "score_teps_q5", "score_teps_q7", "score_teps_q9",
                             "score_teps_q12", "score_teps_q14", "score_teps_q17"]
dfteps[teps_consumatory_questions]= dfteps[teps_consumatory_questions].fillna(0)
dfteps = dfteps.dropna(subset=teps_consumatory_questions)
dfteps[teps_consumatory_questions] = dfteps[teps_consumatory_questions].apply(pd.to_numeric, errors="coerce")
dfteps["Teps_consumatory_sum"] = dfteps[teps_consumatory_questions].sum(axis=1)

result_teps_consumatory = dfteps[["participant_id", "Teps_consumatory_sum"]]

(result_teps_consumatory.head())

(dfteps["Teps_consumatory_sum"].mean())

#consumatory groups.
dfteps["Group"] = dfteps["Teps_consumatory_sum"].apply(
    lambda x: "Non-Clinical" if x >= 36 else "Clinical")# noqa: PLR2004
grouped_teps_consumatory= dfteps.groupby("Group")["Teps_consumatory_sum"].agg(["count",
                                                                                                         "mean",
                                                                                                         "median",
                                                                                                           "std"])
(grouped_teps_consumatory)

# Final Teps table
Teps_final_table= dfteps[["participant_id", "Group", "Teps_questions_sum",
                          "Group", "Teps_anticipatory_sum",
                            "Group", "Teps_consumatory_sum"]]
(Teps_final_table.head())

#trait emotional intelligence שאלון 
dfteipath = r'phenotype/trait_emotional_intelligence.tsv'
dftei = pd.read_csv(dfteipath, sep='\t')
# Display the first few rows
(dftei.head())

#reverse q: 2,4,5,7,8,10,12,13,14,16,18,22,25,26,28.
#emotionality dimension: 1,2,8,13,16,17,23,28.
#self control dimension: 4,7,15,19,22,0.
#well-being dimension: 5,9,12,20,24,27.
# sociability dimension: 6,10,11,21,25,26

#reverse q: 2,4,5,7,8,10,12,13,14,16,18,22,25,26,28.
reverse_tei_question= ["tei_q2", "tei_q4", "tei_q5", "tei_q7", "tei_q8", "tei_q10", "tei_q12", "tei_q13", "tei_q14",
                       "tei_q16", "tei_q18", "tei_q22", "tei_q25", "tei_q26", "tei_q28"]
dftei[reverse_tei_question] = dftei[reverse_tei_question].map(lambda x: 8 - x )

#All questions
Tei_questions= ["tei_q1", "tei_q2", "tei_q3", "tei_q4", "tei_q5", "tei_q6", "tei_q7", "tei_q8", "tei_q9", "tei_q10",
                 "tei_q11", "tei_q12", "tei_q13", "tei_q14", "tei_q15", "tei_q16", "tei_q17", "tei_q18", "tei_q19",
                 "tei_q20", "tei_q21", "tei_q22", "tei_q23", "tei_q24", "tei_q25", "tei_q26", "tei_q27", "tei_q28",
                 "tei_q29", "tei_q30"]
dftei[Tei_questions]= dftei[Tei_questions].fillna(0)
dftei = dftei.dropna(subset=Tei_questions)
dftei[Tei_questions] = dftei[Tei_questions].apply(pd.to_numeric, errors="coerce")
dftei["Tei_sum"] = dftei[Tei_questions].sum(axis=1)

result_tei = dftei[["participant_id", "Tei_sum"]]

(result_tei.head())

(dftei["Tei_sum"].mean())

dftei["Group"] = dftei["Tei_sum"].apply(
    lambda x: "Non-Clinical" if x >= 128 else "Clinical")# noqa: PLR2004
grouped_tei= dftei.groupby("Group")["Tei_sum"].agg(["count", "mean", "median", "std"])
(grouped_tei)

Tei_table= dftei[["participant_id", "Group", "Tei_sum"]]
(Tei_table.head())

#DISPLAY THE RESULTS FOR TESTING THEM 
# creating synthetic data in order to run t tests.
#checking which df doesnt have the collumn participnt_id.
for i, df in enumerate([dfaq, dfmania, dfaadis, dfbdi, dfbpaq, dfctqsf, dfdudit, dfpnr, dfpvss, dfquic, dfrse, dfsusd,
                         dfseq, dfteps, dftei], start=1):
    if "participant_id" not in df.columns:
        (f"participant_id is missing in df{i}")

for i, df in enumerate([dfaq, dfmania, dfaadis, dfbdi, dfbpaq, dfctqsf, dfdudit, dfpnr, dfpvss, dfquic, dfrse, dfsusd,
                         dfseq, dfteps, dftei], start=1):
   print(f"Columns in df{i}: {list(df.columns)}")

for i, df in enumerate([dfaq, dfmania, dfaadis, dfbdi, dfbpaq, dfctqsf, dfdudit, dfpnr, dfpvss, dfquic, dfrse, dfsusd,
                         dfseq, dfteps, dftei], start=1):
    (f"df{i}:")
    ("Columns:", list(df.columns))
    ("Index:", list(df.index))

(dfaq[["participant_id"]].head())  # This will show both columns

dfaq = dfaq.loc[:, ~dfaq.columns.duplicated()]

(dfaq.columns)

(dfmania.columns)

merged_df = pd.concat([dfaq.set_index(["participant_id", "Group"]),
                       dfmania.set_index(["participant_id", "Group"]),
                       dfaadis.set_index(["participant_id", "Group"]),
                       dfbdi.set_index(["participant_id", "Group"]),
                       dfbpaq.set_index(["participant_id", "Group"]),
                       dfctqsf.set_index(["participant_id", "Group"]),
                       dfdudit.set_index(["participant_id", "Group"]),
                       dfpnr.set_index(["participant_id", "Group"]),
                       dfpvss.set_index(["participant_id", "Group"]),
                       dfquic.set_index(["participant_id", "Group"]),
                       dfrse.set_index(["participant_id", "Group"]),
                       dfsusd.set_index(["participant_id", "Group"]),
                       dfseq.set_index(["participant_id", "Group"]),
                       dfteps.set_index(["participant_id", "Group"]),
                       dftei.set_index(["participant_id", "Group"])], axis=1, keys=["AQ", "Altman", "Aadis", "Bdi", "Bpaq",
                                                                          "Ctqsf", "Dudit", "Pnr", "Pvss", "Quic",
                                                                            "Rse", "Susd", "Seq", "Teps", "Tei"])

# Reset index for better readability
merged_df = merged_df.reset_index()
(merged_df)

# Assuming 'clinical' is represented by a certain value in your data, e.g., 1 or 'clinical'
# Let's create a function to count the number of times 'clinical' appears for each participant

def count_clinical_occurrences(df, clinical_value=1):
    # Sum across all columns to get the count of 'clinical' occurrences per participant
    return (df == clinical_value).sum(axis=1)

# Apply this function to your merged dataframe
# Since you have multiple keys (tests), you'll need to access the appropriate part of the merged_df

# Get the clinical occurrences for each participant
clinical_counts = count_clinical_occurrences(merged_df.iloc[:, 2:])
# Adjust the slice to cover all your clinical columns

# Calculate the mean of the clinical counts
mean_clinical_count = clinical_counts.mean()

# Classify participants based on the mean
merged_df["clinical_classification"] = clinical_counts.apply(lambda x: "clinical" if x > mean_clinical_count
                                                              else "non-clinical")

# Now, merged_df has a new column 'clinical_classification' indicating whether a participant is clinical or non-clinical
(merged_df[["participant_id", "clinical_classification"]])

(clinical_counts)

merged_df_filtered = merged_df[["participant_id", "Group"]]
merged_df_filtered = merged_df_filtered.sort_values("participant_id").reset_index(drop=True)

(merged_df_filtered)

pd.set_option("future.no_silent_downcasting", True)  # noqa: FBT003

group_merge_df = merged_df_filtered["Group"]
group_merge_df_encoded = group_merge_df.replace({"Clinical": 2, "Non-Clinical": 1})

#DISPLAY THE RESULTS REAL
# Keep only subject_id and group columns
dfmania_filtered = dfmania[["participant_id", "Group"]]
dfctqsf_filtered = dfctqsf[["participant_id", "Group"]]

dfmania_filtered = dfmania_filtered.sort_values("participant_id").reset_index(drop=True)
dfctqsf_filtered = dfctqsf_filtered.sort_values("participant_id").reset_index(drop=True)

if not dfmania_filtered["participant_id"].equals(dfctqsf_filtered["participant_id"]):
    raise ValueError("Subject IDs do not match.")  # noqa: EM101, TRY003

group_mania = dfmania_filtered["Group"]
group_ctqsf = dfctqsf_filtered["Group"]

# running a test round on dfmania and dfctqsf before on df subjects
# Convert group names to numbers so that i can run the damn t test.
group_mania_encoded = group_mania.replace({"Clinical": 2, "Non-Clinical": 1})
group_ctqsf_encoded = group_ctqsf.replace({"Clinical": 2, "Non-Clinical": 1})
(group_merge_df_encoded)

#OUR END RESULTS WUTH T TEST 
social_reward_stats = np.random.normal(loc=0.01698834814117839, scale=0.0013305286452984042, size= 59)
(social_reward_stats)

financial_reward_stats = np.random.normal(loc=1.0119452121411763, scale=0.00048389448197189383, size= 59)
(financial_reward_stats)

print(group_merge_df_encoded.dtype)
print(social_reward_stats.dtype)

print(group_merge_df_encoded.name)

group_merge_df_encoded = pd.to_numeric(group_merge_df_encoded, errors="coerce")

# Ttests for tasks and participants group_merge_df_encoded
from scipy.stats import ttest_ind

# Perform the t-test
t_stat, p_value = ttest_ind(group_merge_df_encoded, social_reward_stats)

# Display results
print(f"T-statistic: {t_stat:.2f}")
print(f"P-value: {p_value:.4f}")

# Check significance
alpha = 0.05
if p_value < alpha:
    print("The difference is statistically significant.")
else:
    print("The difference is not statistically significant.")

print(len(group_merge_df_encoded))  # Length of group_merge_df_encoded
print(len(social_reward_stats))  # Length of social_reward_stats

# Truncate group_merge_df_encoded to match the length of social_reward_stats
group_merge_df_encoded = group_merge_df_encoded[:len(social_reward_stats)]

# Create a DataFrame with the variables you want to correlate
df = pd.DataFrame({
    "Clinical class": group_merge_df_encoded,
    "Social reward": social_reward_stats
})

# Compute the correlation matrix
correlation_matrix = df.corr()

# Plot the heatmap
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
plt.title('Correlation Matrix Heatmap')
plt.show()


sns.pairplot(df)
plt.show()

# Create a DataFrame with the variables you want to correlate
df_financial_plot = pd.DataFrame({
    "Clinical class": group_merge_df_encoded,
    "financial_reward": financial_reward_stats
})

# Compute the correlation matrix
correlation_matrix = df_financial_plot.corr()

# Plot the heatmap
sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm", vmin=-1, vmax=1)
plt.title("Correlation Matrix Heatmap")
plt.show()

sns.pairplot(df_financial_plot)
plt.show()


# Perform t-test for social_reward against the independent variable 'merged'
t_stat_social, p_value_social = ttest_ind(group_merge_df_encoded, financial_reward_stats)
print(f"Social Reward - T-statistic: {t_stat_social:.2f}, P-value: {p_value_social:.4f}")

# Perform t-test for financial_reward against the independent variable 'merged'
t_stat_financial, p_value_financial = ttest_ind(group_merge_df_encoded, social_reward_stats)
(f"Financial Reward - T-statistic: {t_stat_financial:.2f}, P-value: {p_value_financial:.4f}")

# Assuming the t-test results
results = {
    "Dependent Variable": ["social reward", "financial reward"],
    "T-statistic": [t_stat_social, t_stat_financial],
    "P-value": [p_value_social, p_value_financial],
    "Degrees of Freedom": [social_reward_stats, financial_reward_stats]  # Replace with actual degrees of freedom if needed
}

# Create DataFrame
t_test_results_df = pd.DataFrame(results)

# Display the table
(t_test_results_df)

# Example: Create a DataFrame with 'Group', 'Social Reward', and 'Financial Reward' columns
df_plot = pd.DataFrame({
    "Clinical class": group_merge_df_encoded,  # Assuming this is your independent variable
    "Social Reward": social_reward_stats,  # Your first dependent variable
    "Financial Reward": financial_reward_stats  # Your second dependent variable
})

# Reshaping the data into long format
df_long = pd.melt(df_plot, id_vars=["Clinical class"], value_vars=["Social Reward", "Financial Reward"],
                  var_name="Variable", value_name="Value")

# Checking the reshaped DataFrame
(df_long.head())


(df_long.columns)

print(df.columns)

#ניתוח FMRI
from scipy.ndimage import gaussian_filter

path1 = r'sourcedata/sub-1001/sub-1001_face-A.tsv'
df_SUB1001 = pd.read_csv(path1, sep='\t')
df_SUB1001.head()  #העלת קובץ של המטלה עבור נבדק 1 
path2 = r'sourcedata\sub-1002\sub-1002_face-A.tsv'
df_SUB1002 = pd.read_csv(path2, sep='\t')
df_SUB1002.head() #העלת קובץ של המטלה עבור נבדק 2 
path3 = r'sourcedata\sub-1003\sub-1003_face-A.tsv'
df_SUB1003 = pd.read_csv(path3, sep='\t')
df_SUB1003.head() #העלת קובץ של המטלה עבור נבדק 3 
path4 = r'sourcedata\sub-1004\sub-1004_face-A.tsv'
df_SUB1004 = pd.read_csv(path4, sep='\t')
df_SUB1004.head() #העלת קובץ של המטלה עבור נבדק 4 

df_SUB1001["subject_id"] = "SUB1001" #כדי שאוכל להציג לאחר מכן פר נבדק 
df_SUB1002["subject_id"] = "SUB1002"
df_SUB1003["subject_id"] = "SUB1003"
df_SUB1004["subject_id"] = "SUB1004"
mydataframe = [df_SUB1001,df_SUB1002, df_SUB1003, df_SUB1004]
merged_mydataframe = pd.concat(mydataframe, ignore_index=True) #חיבור בין נתונים ליצירת עמודה של הנבדקים 
merged_mydataframe

merged_mydataframe.isnull().sum() #בדיקת ערכים חסרים 
merged_mydataframe = merged_mydataframe.bfill() #מילוי ערכים חסרים 
merged_mydataframe.isnull().sum() #בדיקת ערכים חסרים 

merged_mydataframe['reaction_fmri'] = merged_mydataframe['resp'] - merged_mydataframe['rt']
merged_mydataframe

merged_mydataframe['reaction_fmri'].isnull().sum().sum()

merged_mydataframe.bfill()

merged_mydataframe.isnull().sum().sum()

from scipy.stats import pearsonr, spearmanr
pearson_corr, p_value_pearson = pearsonr(merged_mydataframe['reaction_fmri'], merged_mydataframe['resp'])
print(f"Pearson Correlation: {pearson_corr}, p-value: {p_value_pearson}") #מתאם פירסון 
spearman_corr, p_value_spearman = spearmanr(merged_mydataframe['reaction_fmri'], merged_mydataframe['resp'])
print(f"Spearman Correlation: {spearman_corr}, p-value: {p_value_spearman}") #מתאם ספירמן 

import statsmodels.api as sm #רגרסיה ליניארית 
X = merged_mydataframe['resp']  # משתנה מסביר
y = merged_mydataframe['reaction_fmri']  # משתנה מוסבר
X = sm.add_constant(X)
model = sm.OLS(y, X).fit()
print(model.summary())

import matplotlib.pyplot as plt
import seaborn as sns
sns.lmplot(x='resp', y='reaction_fmri', data=merged_mydataframe)
plt.xlabel('Reaction Time Original')
plt.ylabel('Reaction in fMRI')
plt.title('Linear Relationship between Reaction Time and fMRI Signal')
plt.show()

#בדיקה של סיגנלים מוחים כתגובה על חשיפה לפנים 
df_SUB1001["subject_id"] = "SUB1001" #כדי שאוכל להציג לאחר מכן פר נבדק 
df_SUB1002["subject_id"] = "SUB1002"
df_SUB1003["subject_id"] = "SUB1003"
df_SUB1004["subject_id"] = "SUB1004"
mydataframe = [df_SUB1001,df_SUB1002, df_SUB1003, df_SUB1004]
merged_mydataframe = pd.concat(mydataframe, ignore_index=True) #חיבור בין נתונים ליצירת עמודה של הנבדקים 
merged_mydataframe

merged_mydataframe["rt"] #זמן תגובה ,פלטור לפי עמודה 

df = merged_mydataframe.groupby("subject_id")["onset"].first()  # הצגה של משתנה onset פר נבדק
print(df)

df = merged_mydataframe.groupby("subject_id")["rt"].first()  # הצגה של משתנה rt פר נבדק
print(df)

merged_mydataframe.head()

df_range = pd.DataFrame(merged_mydataframe)
df_range['end'] = df_range['onset'] + df_range['duration']  # חישוב סיום כל ניסוי
df_range

print(df_range.head())  # מציג את 5 השורות הראשונות בדאטה פריים
print(df_range.columns)  # מציג את שמות העמודות

print(df_range.isnull().sum().sum())#בדיקת ערכים חסרים 

df_range = df_range.bfill()#מילוי ערכים חסרים בערכים הבאים 

print(df_range.isnull().sum().sum())#בדיקת ערכים חסרים 

print(df_range.columns) #בדיקת עמודות 

selected_colums=df_range[['subject_id','rt', 'end']] #טבלה רק של 3 מדדים של זמן תגובה 
selected_colums

df_range['end'] = pd.to_numeric(df_range['end'],errors='coerce')#המרה לנומרי 
print(df_range.isnull().sum().sum())

selected_colums.columns #מה העמודות שלי 

grouped_table = df_range.groupby("subject_id")["end"].apply(list).reset_index() #ערכים לבטלת של נבדקים עבור END- סיום התגובה 
grouped_table["subject_id"] = grouped_table["subject_id"] #הוספה של עמודת הנבדקים 
df_range_end_columns = grouped_table["end"].apply(pd.Series) #סיום תגובה זאת עמודה נפרדת 
df_range_end_columns.columns = [f't{i+1}' for i in range(df_range_end_columns .shape[1])]#יצירת שמות בהתאמה לכל העמודה 
df_range_end_columns ["subject_id"] = grouped_table["subject_id"] #עמודות של הנבדקים הן נפרדות 
df_range_end_columns ['original_end'] = grouped_table['end'] #שמירה על הערכים המקוריים 
df_range_end_columns = df_range_end_columns[['subject_id'] + [col for col in df_range_end_columns.columns if col != 'subject_id']]
df_range_end_columns 

sample_friquency=300 #תדירות הדגימה
num_of_samples=4 #מספר דגימות 
duration_seconds=4/300*100 #משך דגימה בדקות
duration_seconds
t = np.linspace(0, duration_seconds, int(sample_friquency * duration_seconds), endpoint=False) #כל ערכי זמן המייצגים את הדגימות במשך 0.1 שניה 
print(f"משך הדגימה בפועל: {len(t) / sample_friquency} שניות") 

freq1, freq2 = 5,50 #במחירת תדר נמוך וגבוה, אבל לא גבוה יותר מחצי של תדירות הדגימה (בשביל שלא תהיה סטייה גבוהה מדיי) 
signal=np.sin(2*np.pi*freq1*t)+0.5*np.sin(2*np.pi*freq2*t) #הפרש בין שני גלי סינוסים, חישוב הטדירות והאמפליטודה #מכפילים ב2 כי מחשבים סינוס ברדיאנים 2 פאי, אמפיטודה של סינוס בין 1 ל-1 אז אוכל להשתמש בערכים שביניהם 

fft_transform=np.fft.fft(signal) #המרה של זמן לתדירות 
frequencies=np.fft.fftfreq(len(signal),d=1/sample_friquency)

plt.figure(figsize=(10, 6))
plt.plot(frequencies[:len(frequencies)//2], np.abs(fft_transform)[:len(fft_transform)//2]) #בוחרת תדרים חיוביים כי שליליים לא רלוונטיים לי 
plt.title('Frequencies')
plt.xlabel('freq (Hz)')
plt.ylabel('Amlitude')
plt.grid(True)
plt.show()

padded_signal=np.pad(signal,(0,300),mode='constant')#בגלל שהוספתי פילטר לפני כן ולא רוצה לאבד מידע 

fft_transform=np.fft.fft(signal)
fft_padded=np.fft.fft(padded_signal)
frequencies=np.fft.fftfreq(len(signal),d=1/sample_friquency)
frequencies_padded=np.fft.fftfreq(len(padded_signal),d=1/sample_friquency)

plt.figure(figsize=(12, 6))
plt.subplot(2,1,1)
plt.plot(t,signal,label="Original Signal")
plt.title('Original Signal')
plt.xlabel('time(min)')
plt.ylabel('Amplitude')
plt.legend()
plt.show()

sample_frequency=300 
plt.subplot(2, 1, 2)
plt.plot(frequencies[:sample_frequency//2], np.abs(fft_transform)[:sample_frequency//2], label='Original FFT')
plt.plot(frequencies_padded[:len(padded_signal)//2], np.abs(fft_padded)[:len(padded_signal)//2], label='Padded FFT', linestyle='dashed')
plt.title('Original vs Padded')
plt.xlabel('Frequency (Hz)')
plt.ylabel('Amplitude')
plt.legend()
plt.tight_layout()
plt.show()

threshold=80  #פונקציה התחלתית לעומת פונקציה מפולטרת 
fft_transform[np.abs(frequencies) > threshold] = 0
smoothed_signal = np.fft.ifft(fft_transform)# חזרה לאות במרחב הזמן
plt.plot(t, signal, label="Signal")
plt.plot(t, smoothed_signal.real, label="Smoothed Signal", linestyle='--')
plt.legend()
plt.show()

def gaussian_kernel(size, sigma=1): #החלקת פונקציה ''גאוסיאני'
    x = np.linspace(-size//2, size//2, size)
    kernel = np.exp(-0.5 * (x / sigma)**2)
    kernel = kernel / kernel.sum()  # נרמל את הגרעין כך שהסכום יהיה 1
    return kernel

kernel_size = 51
sigma = 5
gaussian = gaussian_kernel(kernel_size, sigma)
smoothed_signal = np.convolve(signal, gaussian, mode='same')
plt.plot(t, signal, color='pink', label="Original Signal")
plt.plot(t, smoothed_signal, color='blue', label="Smoothed Signal (Gaussian)", linestyle='--')
plt.legend()
plt.show()

#בדיקות סיגנלים פר נבדק
print("מספר שורות:", df_range.shape[0])  # מספר השורות
print("מספר עמודות:", df_range.shape[1])  # מספר העמודות

sample_friquency1=342 #תדירות הדגימה 1200/3.5
num_of_samples=1200 #מספר דגימות 
duration_seconds1=3.5 #משך דגימה בדקות - מהמאמר
duration_seconds1

t1 = np.linspace(0, duration_seconds1, int(sample_friquency1 * duration_seconds1), endpoint=False) #כל ערכי זמן המייצגים את הדגימות במשך 0.1 שניה 
print(f"משך הדגימה בפועל: {len(t) / sample_friquency1} שניות") 

freq1=50 #בחרתי ערך נמוך וערך גבוהה 
freq2=300
signal2=np.sin(2*np.pi*freq1*t1)+0.5*np.sin(2*np.pi*freq2*t1)

fft_transform2=np.fft.fft(signal2) #המרה של זמן לתדירות 
frequencies2=np.fft.fftfreq(len(signal2),d=3.5/sample_friquency1)

plt.figure(figsize=(10, 6))
plt.plot(frequencies2[:len(frequencies2)//2], np.abs(fft_transform2)[:len(fft_transform2)//2]) #בוחרת תדרים חיוביים כי שליליים לא רלוונטיים לי 
plt.title('Frequencies')
plt.xlabel('freq (Hz)')
plt.ylabel('Amlitude')
plt.grid(True)
plt.show()

df_range_end_columns.columns
print(df_range_end_columns['subject_id'].unique())
df_range_end_columns = df_range_end_columns.drop('original_end', axis=1)  # axis=1 מציין שהפעולה היא על עמודות

#נבדק1 
subject_data = df_range_end_columns[df_range_end_columns['subject_id'] == 'SUB1001'] #פלטור דאטה בשביל נבדק 1 
print(subject_data) #בדיקה שנבדק כולל את הערכים הנדרשים 
time_points = subject_data.columns[1:]  # Time points (e.g., t1, t2, t3, ...) עבור נבדק 1 
values = subject_data.iloc[0, 1:].values  # Values 
print(values)
plt.figure(figsize=(60, 46))
plt.plot(time_points, values, marker='o', label='SUB1001')
plt.title('Time Series for SUB1001')
plt.xlabel('Time Points')
plt.ylabel('Values')
plt.xticks(rotation=45)
plt.grid()
plt.legend()
plt.tight_layout()
plt.show()

time_points_numeric = np.arange(len(time_points))
amplitudemy = 1  # גובה (Amplitude)
frequencymy = 1  # תדר (Frequency) ב-Hz
signalmy = amplitudemy * np.sin(2 * np.pi * frequencymy * time_points_numeric)

fft_signalmy = np.fft.fft(signalmy) #חיושב פוריה 
frequenciesmy = np.fft.fftfreq(len(signalmy), d=(time_points_numeric[1] - time_points_numeric[0]))

plt.figure(figsize=(10, 5)) #הצגת הFFT 
# הצגת התדרים האמיתיים
plt.plot(frequenciesmy[:len(frequenciesmy)//2], np.abs(fft_signalmy)[:len(fft_signalmy)//2])  # הצגת התדרים החיוביים
plt.title('FFT of the signal ')
plt.xlabel('friquency (Hz)')
plt.ylabel('amplitude')
plt.grid(True)
plt.show()

window_size = 50 #חלון גדול חסית אבל רואים פחות פרטים 
smoothed_signal = np.convolve(signalmy, np.ones(window_size)/window_size, mode='same') #החלקת הנתנים על ידי בחירת חלון 

plt.figure(figsize=(10, 5))
plt.plot(time_points, signalmy, label="Original signal")
plt.plot(time_points, smoothed_signal, label="smoothed_signal ", linewidth=2)
plt.title("smoothed_signal_with_mean")
plt.xlabel("time")
plt.ylabel("amplitude")
plt.legend()
plt.grid(True)
plt.show()

sigma = np.std(time_points_numeric) #בשביל גרעין גאוסיאני
sigma
size = int(6 * sigma) #בשביל גרעין גאוסיאני 
size

def gaussian_kernel(size, sigma=1):
    kernel = np.exp(-np.linspace(-size//2, size//2, size)**2 / (2*sigma**2))
    kernel = kernel / kernel.sum()  # Normalize to ensure sum equals 1
    return kernel
size = 519  # Kernel size
sigma = 86  # Standard deviation
kernel2 = gaussian_kernel(size, sigma)
kernel2 = kernel2[:len(signalmy)] 
smoothed_signal2 = np.convolve(signalmy, kernel2, mode='same') #החלקה גאוסיאנית 
plt.figure(figsize=(10, 5))
plt.plot(time_points, signalmy, label="Original signal")
plt.plot(time_points, smoothed_signal2, label="smoothed gausian signal", linewidth=2)
plt.title("smoothed gausian signal")
plt.xlabel("time")
plt.ylabel("amplitude")
plt.legend()
plt.grid(True)
plt.show()

#נבדק 2 
subject_data2 = df_range_end_columns[df_range_end_columns['subject_id'] == 'SUB1002'] #פלטור דאטה בשביל נבדק 2 
print(subject_data2) #בדיקה שנבדק כולל את הערכים הנדרשים 

time_points2 = subject_data2.columns[1:]  # Time points (e.g., t1, t2, t3, ...) עבור נבדק 1 
values = subject_data2.iloc[0, 1:].values  # Values 
print(values)
plt.figure(figsize=(60, 46))
plt.plot(time_points2, values, marker='o', label='SUB1002')
plt.title('Time Series for SUB1002')
plt.xlabel('Time Points')
plt.ylabel('Values')
plt.xticks(rotation=45)
plt.grid()
plt.legend()
plt.tight_layout()
plt.show()

time_points_numeric2 = np.arange(len(time_points2)) #חישוב עבור נבדק 2 
amplitudemy2 = 1  # גובה (Amplitude)
frequencymy2 = 1  # תדר (Frequency) ב-Hz
signalmy2 = amplitudemy2 * np.sin(2 * np.pi * frequencymy2 * time_points_numeric2)

fft_signalmy2 = np.fft.fft(signalmy2) #חיושב פוריה 
frequenciesmy2 = np.fft.fftfreq(len(signalmy2), d=(time_points_numeric2[1] - time_points_numeric2[0]))

plt.figure(figsize=(10, 5)) #הצגת הFFT 
plt.plot(frequenciesmy2[:len(frequenciesmy2)//2], np.abs(fft_signalmy2)[:len(fft_signalmy2)//2])  # הצגת התדרים החיוביים
plt.title('FFT of the signal ')
plt.xlabel('friquency (Hz)')
plt.ylabel('amplitude')
plt.grid(True)
plt.show()

window_size2 = 10 #חלון קטן חסית  ורואים יותר פרטים 
smoothed_signal2 = np.convolve(signalmy2, np.ones(window_size2)/window_size2, mode='same')

plt.figure(figsize=(10, 5))
plt.plot(time_points2, signalmy2, label="Original signal")
plt.plot(time_points2, smoothed_signal2, label="smoothed_signal ", linewidth=2)
plt.title("smoothed_signal_with_mean")
plt.xlabel("friquency")
plt.ylabel("amplitude")
plt.legend()
plt.grid(True)
plt.show()

#נבדק3
subject_data3 = df_range_end_columns[df_range_end_columns['subject_id'] == 'SUB1003'] #פלטור דאטה בשביל נבדק 3 
print(subject_data3) #בדיקה שנבדק כולל את הערכים הנדרשים 

time_points3 = subject_data.columns[1:]  # Time points (e.g., t1, t2, t3, ...) עבור נבדק 1 
values3 = subject_data.iloc[0, 1:].values  # Values 
print(values3)
plt.figure(figsize=(60, 46))
plt.plot(time_points3, values3, marker='o', label='SUB1003')
plt.title('Time Series for SUB1003')
plt.xlabel('Time Points')
plt.ylabel('Values')
plt.xticks(rotation=45)
plt.grid()
plt.legend()
plt.tight_layout()
plt.show()

time_points_numeric3 = np.arange(len(time_points3)) #חישוב עבור נבדק 2 
amplitudemy3 = 1  # גובה (Amplitude)
frequencymy3 = 1  # תדר (Frequency) ב-Hz
signalmy3 = amplitudemy3 * np.sin(2 * np.pi * frequencymy3 * time_points_numeric3)

fft_signalmy3 = np.fft.fft(signalmy3) #חיושב פוריה 
frequenciesmy3 = np.fft.fftfreq(len(signalmy3), d=(time_points_numeric3[1] - time_points_numeric3[0]))

plt.figure(figsize=(10, 5)) #הצגת הFFT 
plt.plot(frequenciesmy3[:len(frequenciesmy3)//2], np.abs(fft_signalmy3)[:len(fft_signalmy3)//2])  # הצגת התדרים החיוביים
plt.title('FFT of the signal ')
plt.xlabel('friquency (Hz)')
plt.ylabel('amplitude')
plt.grid(True)
plt.show()

window_size3 = 30 #חלון קטן חסית  ורואים יותר פרטים 
smoothed_signal3 = np.convolve(signalmy3, np.ones(window_size3)/window_size3, mode='same')

plt.figure(figsize=(10, 5))
plt.plot(time_points3, signalmy3, label="Original signal")
plt.plot(time_points3, smoothed_signal3, label="smoothed_signal ", linewidth=2)
plt.title("smoothed_signal_with_mean")
plt.xlabel("friquency")
plt.ylabel("amplitude")
plt.legend()
plt.grid(True)
plt.show()

#נבדק 4
subject_data4 = df_range_end_columns[df_range_end_columns['subject_id'] == 'SUB1004'] #פלטור דאטה בשביל נבדק 4 
print(subject_data4) #בדיקה שנבדק כולל את הערכים הנדרשים 

time_points4 = subject_data.columns[1:]  # Time points (e.g., t1, t2, t3, ...) עבור נבדק 1 
values4 = subject_data.iloc[0, 1:].values  # Values 
print(values4)
plt.figure(figsize=(60, 46))
plt.plot(time_points4, values4, marker='o', label='SUB1004')
plt.title('Time Series for SUB1004')
plt.xlabel('Time Points')
plt.ylabel('Values')
plt.xticks(rotation=45)
plt.grid()
plt.legend()
plt.tight_layout()
plt.show()

time_points_numeric4 = np.arange(len(time_points4)) #חישוב עבור נבדק 4 
amplitudemy4 = 1  # גובה (Amplitude)
frequencymy4 = 1  # תדר (Frequency) ב-Hz
signalmy4 = amplitudemy4 * np.sin(2 * np.pi * frequencymy4 * time_points_numeric4)

fft_signalmy4 = np.fft.fft(signalmy4) #חיושב פוריה 
frequenciesmy4 = np.fft.fftfreq(len(signalmy4), d=(time_points_numeric4[1] - time_points_numeric4[0]))

plt.figure(figsize=(10, 5)) #הצגת הFFT 
plt.plot(frequenciesmy4[:len(frequenciesmy4)//2], np.abs(fft_signalmy4)[:len(fft_signalmy4)//2])  # הצגת התדרים החיוביים
plt.title('FFT of the signal ')
plt.xlabel('friquency (Hz)')
plt.ylabel('amplitude')
plt.grid(True)
plt.show()

window_size4 = 60 #חלון גדול חסית  ורואים פחות פרטים 
smoothed_signal4 = np.convolve(signalmy4, np.ones(window_size4)/window_size4, mode='same')

plt.figure(figsize=(10, 5))
plt.plot(time_points4, signalmy4, label="Original signal")
plt.plot(time_points4, smoothed_signal4, label="smoothed_signal ", linewidth=2)
plt.title("smoothed_signal_with_mean")
plt.xlabel("friquency")
plt.ylabel("amplitude")
plt.legend()
plt.grid(True)
plt.show()











