import os
import pandas as pd
import matplotlib.pyplot as plt

def load_and_display_csv_files(): #פונקציה שמטעינה ומאחדת את הדאטאפריימס
    base_path = r'sourcedata\\UGDG\\logs'#תיקיית הבסיס 
    dataframes = [] #לשמור רשימה 

    for folder in os.listdir(base_path): #זה מה שמושך את הקבצים קובץ קובץ 
        folder_path = os.path.join(base_path, folder)
        if not os.path.isdir(folder_path):
            continue  # דלג על קבצים אם יש כאלה בתיקיית הבסיס

        for file in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file)
            if file.endswith(".csv"):  # בדוק אם הקובץ הוא קובץ CSV
                try:
                    df = pd.read_csv(file_path)
                    dataframes.append(df)
                    print(f"Successfully loaded: {file_path}")
                except Exception as e:
                    print(f"Error loading {file_path}: {e}")

    if not dataframes:
        print("No files were loaded successfully.") #הטסטס על הפונקציה 
        return None

    # איחוד כל הטבלאות למסגרת נתונים אחת
    try:
        merged_df = pd.concat(dataframes, ignore_index=True)
        print("Successfully merged the DataFrames.")
    except Exception as e:
        print(f"Error merging DataFrames: {e}")
        return None

    # הצגת סך הכל שורות ועמודות
    print("Total Rows and Columns in the Merged DataFrame:")
    print(f"Rows: {merged_df.shape[0]}, Columns: {merged_df.shape[1]}")
    print(merged_df.head())  # מציג 5 שורות הראשונות

    return merged_df  # הצגת העמודות הסופיות של דאטה פריים 



load_and_display_csv_files()#קריאה לפונקציה 

def process_merged_dataframe(merged_df): #פונקציה שעושה ניקוי דאטה 
    if merged_df is None:
        print("No DataFrame to process.")
        return
    
    # הצגת מידע כללי על הנתונים
    print("Information about the DataFrame:")
    merged_df.info()

    # תיאור של הנתונים
    print("\nDescriptive statistics of the DataFrame:")
    print(merged_df.describe())

    # סיכום של הערכים החסרים
    print("\nMissing values in the DataFrame:")
    print(merged_df.isnull().sum())

    # הצגת שמות העמודות
    print("\nColumns in the DataFrame:")
    print(merged_df.columns)

    # מחיקת עמודות מיותרות
    merged_df.drop(['ran', 'nTrial', 'L_Option', 'order'], axis=1, inplace=True)
    print("\nColumns after dropping unnecessary ones:")
    print(merged_df.columns)

    # הצגת 5 השורות הראשונות
    print("\nFirst 5 rows of the DataFrame after cleanup:")
    print(merged_df.head())

    # הצגת טווח של עמודות desision onset וdesision ofset ליצירת משתנה חדש 
    print("\nSelected rows based on 'decision_onset' and 'decision_offset' columns:")
    print(merged_df.iloc[0:2125, [merged_df.columns.get_loc('decision_onset'), merged_df.columns.get_loc('decision_offset')]])

    # המרת עמודות לאינדקסים
    indexfordecision = merged_df.set_index(['decision_onset', 'decision_offset'])
    print("\nDataFrame after setting 'decision_onset' and 'decision_offset' as index:")
    print(indexfordecision.head())

    return indexfordecision


# קריאה לפונקציות
merged_df = load_and_display_csv_files()
if merged_df is not None:
    process_merged_dataframe(merged_df)



def process_times(merged_df):
    # רשימת עמודות רלוונטיות ללמשתנים חדשים בהמשך 
    columns_to_process = ['decision_offset', 'decision_onset', 'endowment_offset', 'endowment_onset']

    # המרת ערכים למספריים ומילוי ערכים חסרים בערך ממוצע
    for col in columns_to_process:
        merged_df[col] = pd.to_numeric(merged_df[col], errors='coerce')
        merged_df[col].fillna(merged_df[col].mean(), inplace=True)

    # יצירת עמודות טווחי זמן
    merged_df['decision_time_range_for_all'] = merged_df['decision_offset'] - merged_df['decision_onset']
    merged_df['endowment_time_range_for_all'] = merged_df['endowment_offset'] - merged_df['endowment_onset']

    # הצגת תוצאות
    print("תוצאות טווח החלטה:")
    print(merged_df['decision_time_range_for_all'].head(min(2125, len(merged_df))))
    
    print("\תוצאות טווח זמן התמורה:")
    print(merged_df[['endowment_onset', 'endowment_offset']].head(min(2125, len(merged_df))))

    # המרת עמודות לאינדקסים
    indexfordecision = merged_df.set_index(['endowment_onset', 'endowment_offset'])

    # מחזיר את התוצאות
    return (merged_df['decision_time_range_for_all'].head(min(2125, len(merged_df))), 
            merged_df[['endowment_onset', 'endowment_offset']].head(min(2125, len(merged_df))), 
            indexfordecision)


# לקרוא לפונקציה
decision_time_range_result, endowment_result, indexfordecision = process_times(merged_df)

print(merged_df.head())
print(list(merged_df.columns))


def calculate_means_and_std(merged_df):
    # חישוב ממוצע עבור decision_time_range_for_all
    decision_time_range_mean = merged_df['decision_time_range_for_all'].mean()
    # חישוב ממוצע עבור endowment_time_range_for_all
    endowment_time_range_mean = merged_df['endowment_time_range_for_all'].mean()
    # חישוב סטיית תקן עבור decision_time_range_for_all
    decision_time_range_std = merged_df['decision_time_range_for_all'].std()
    # חישוב סטיית תקן עבור endowment_time_range_for_all
    endowment_time_range_std = merged_df['endowment_time_range_for_all'].std()
    # החזרת הממוצעים וסטיית התקן
    return decision_time_range_mean, endowment_time_range_mean, decision_time_range_std, endowment_time_range_std

# קריאה לפונקציה והדפסת התוצאות
decision_time_range_mean, endowment_time_range_mean, decision_time_range_std, endowment_time_range_std = calculate_means_and_std(merged_df)

# הדפסת התוצאות
print(f"ממוצע טווח ההחלטה: {decision_time_range_mean}")
print(f"ממוצע טווח זמן התמורה: {endowment_time_range_mean}")
print(f"סטיית תקן עבור טווח ההחלטה: {decision_time_range_std}")
print(f"סטיית תקן עבור טווח זמן התמורה: {endowment_time_range_std}")



def calculate_correlation_matrix(merged_df, columns):
#בדיקה של כל העמודות של דאטה פריים 
    if not all(col in merged_df.columns for col in columns):
        print("One or more columns are not in the DataFrame.")
        return None
    # בחירת עמודות 
    merged_df_selected = merged_df[columns]
    # העברה למספרים שלמים 
    merged_df_selected = merged_df_selected.apply(pd.to_numeric, errors='coerce')
    # לחתוך ערכים חסרים 
    merged_df_selected = merged_df_selected.dropna()
    # לחשב מטריצה של קשרים 
    correlation_matrix = merged_df_selected.corr()
    return correlation_matrix

# קריאת פונקציה
columns_to_select = ['decision_time_range_for_all', 'endowment_time_range_for_all', 'resp_onset']
correlation_matrix_for_all = calculate_correlation_matrix(merged_df, columns_to_select)

#הדפסת מטריצה 
if correlation_matrix_for_all is not None:
    print(correlation_matrix_for_all)


def create_reward_variables(merged_df):
    if 'endowment_time_range_for_all' not in merged_df.columns:
        print("'endowment_time_range_for_all' column is missing in the DataFrame.")
        return None

    # בדיקת ערכים חסרים ב-endowment_time_range_for_all
    nan_count = merged_df['endowment_time_range_for_all'].isnull().sum()
    if nan_count > 0:
        merged_df['endowment_time_range_for_all'].fillna(method='bfill', inplace=True)  # מילוי אחורי
        print("\nMissing values in 'endowment_time_range_for_all' filled using backward fill (bfill).")
    
    # חישוב ממוצע עבור 'endowment_time_range_for_all'
    mean_endowment_time_range_for_all = merged_df['endowment_time_range_for_all'].mean()
    print(f"\ממוצע של טווח זמן התמורה: {mean_endowment_time_range_for_all}")

    # יצירת המשתנה 'social_reward'
    merged_df['social_reward'] = merged_df['endowment_time_range_for_all'].apply(
        lambda x: x if x < mean_endowment_time_range_for_all else None
    )
    
    # יצירת המשתנה 'financial_reward'
    merged_df['financial_reward'] = merged_df['endowment_time_range_for_all'].apply(
        lambda x: x if x > mean_endowment_time_range_for_all else None
    )

    # בדיקה ומילוי ערכים חסרים עבור 'social_reward'
    merged_df["social_reward"] = merged_df["social_reward"].fillna(merged_df["social_reward"].max())
    print("\nMissing values in 'social_reward' filled with its maximum value.")

    # בדיקה ומילוי ערכים חסרים עבור 'financial_reward'
    merged_df["financial_reward"] = pd.to_numeric(merged_df["financial_reward"], errors='coerce')  # הבטחת נתונים מספריים
    merged_df["financial_reward"] = merged_df["financial_reward"].fillna(merged_df["financial_reward"].max())
    print("\nMissing values in 'financial_reward' filled with its maximum value.")

    # הצגת 5 השורות הראשונות עם המשתנים החדשים
    print("\nDataFrame with new reward variables (first 5 rows):")
    print(merged_df[['endowment_time_range_for_all', 'social_reward', 'financial_reward']].head())

    return merged_df

merged_df = create_reward_variables(merged_df) #מימוש פונקציה 
if merged_df is not None:
    print("\nUpdated DataFrame:")
    print(merged_df.head())

def calculate_reward_averages(merged_df):
    if 'financial_reward' not in merged_df.columns or 'social_reward' not in merged_df.columns:
        print("'financial_reward' or 'social_reward' column is missing in the DataFrame.")
        return None
    
    # חישוב ממוצע עבור 'financial_reward'
    mean_financial_reward = merged_df['financial_reward'].mean()
    print(f"\ממוצע של 'financial_reward': {mean_financial_reward}")

    # חישוב ממוצע עבור 'social_reward'
    mean_social_reward = merged_df['social_reward'].mean()
    print(f"\ממוצע של 'social_reward': {mean_social_reward}")
    
    return mean_financial_reward, mean_social_reward

# קריאה לפונקציה
mean_financial_reward, mean_social_reward = calculate_reward_averages(merged_df)


def calculate_std_rewards(merged_df): #חישוב סטיית התקן עבור משתנים 
    if 'social_reward' in merged_df.columns and 'financial_reward' in merged_df.columns:
        std_social_reward = merged_df['social_reward'].std()
        std_financial_reward = merged_df['financial_reward'].std()
        
        print(f"Std for social reward: {std_social_reward}")
        print(f"Std for finantial reward: {std_financial_reward}")
    else:
        print("אחת או יותר מהעמודות 'social_reward' או 'financial_reward' אינן קיימות ב-DataFrame.")

calculate_std_rewards(merged_df)




def load_subject_data2(file_path): #    טוען קובץ CSV לפי נתיב נתון ומחזיר את חמש השורות הראשונות של הנתונים.
    try:
        df = pd.read_csv(file_path, sep='\t')
        print(f"Successfully loaded data from {file_path}")
        return df
    except Exception as e:
        print(f"Failed to load data from {file_path}: {e}")
        return None

# בניית רשימת הנתיבים אוטומטית
subject_ids = [1001, 1002, 1003, 1004]  # מספרי הנבדקים
base_path = r'sourcedata'

file_paths = [
    f"{base_path}/sub-{sub_id}/sub-{sub_id}_face-A.tsv"
    for sub_id in subject_ids
]

# קריאת הקבצים
dataframes = [load_subject_data2(path) for path in file_paths]


def merge_subject_data(dataframes, subject_ids): #חיבור בין הקבצים (פר נבדקים ביחד לקובץ אחד)
    for df, subject_id in zip(dataframes, subject_ids):
        if df is not None:
            df["subject_id"] = subject_id
    
    # מיזוג ה-DataFrames
    merged_dataframe = pd.concat([df for df in dataframes if df is not None], ignore_index=True)
    return merged_dataframe


subject_ids = ["SUB1001", "SUB1002", "SUB1003", "SUB1004"] #מימוש של הפונקציה 
# קריאת הנתונים מהקבצים (מהפונקציה הקודמת)
dataframes = [load_subject_data2(path) for path in file_paths]
# מיזוג הנתונים
merged_data = merge_subject_data(dataframes, subject_ids)
# הצגת התוצאה
print(merged_data)

def handle_missing_data_and_calculate_reaction(merged_data): #ניקוי דאטה 
    # בדיקת ערכים חסרים לפני הטיפול
    print("Missing values before filling:", merged_data.isnull().sum())
    # מילוי ערכים חסרים בעזרת bfill
    merged_data = merged_data.bfill()
    # בדיקת ערכים חסרים אחרי המילוי
    print("Missing values after filling:", merged_data.isnull().sum())
    # חישוב 'reaction_fmri' 
    merged_data['reaction_fmri'] = merged_data['resp'] - merged_data['rt']
    # בדיקת ערכים חסרים בעמודת 'reaction_fmri'
    missing_reaction_fmri = merged_data['reaction_fmri'].isnull().sum()
    print(f"Missing values in 'reaction_fmri': {missing_reaction_fmri}")
    # מילוי ערכים חסרים אם יש
    merged_data = merged_data.bfill()
    # סיכום ערכים חסרים
    total_missing_values = merged_data.isnull().sum().sum()
    print(f"Total missing values after final fill: {total_missing_values}")
    return merged_data


from scipy.stats import pearsonr, spearmanr

def calculate_correlation(df, col1, col2):
    # חישוב מתאם פירסון
    pearson_corr, p_value_pearson = pearsonr(df[col1], df[col2])
    print(f"Pearson Correlation: {pearson_corr}, p-value: {p_value_pearson}")
    # חישוב מתאם ספירמן
    spearman_corr, p_value_spearman = spearmanr(df[col1], df[col2])
    print(f"Spearman Correlation: {spearman_corr}, p-value: {p_value_spearman}")



