import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib 
import matplotlib.pyplot as plt


def plot_means_and_std(means_and_std):
    # פריסה של הערכים מהפונקציה
    decision_time_mean, endowment_time_mean, decision_time_std, endowment_time_std = means_and_std

    # הכנת הנתונים לגרף
    categories = ['Decision Time Range', 'Endowment Time Range']
    means = [decision_time_mean, endowment_time_mean]
    stds = [decision_time_std, endowment_time_std]

    # יצירת גרף עמודות עם קווי שגיאה
    plt.figure(figsize=(8, 6))
    plt.bar(categories, means, yerr=stds, capsize=10, color=['skyblue', 'lightgreen'], alpha=0.8)

    # הוספת כותרות וצירים
    plt.title('Means and Standard Deviations', fontsize=16)
    plt.ylabel('Values', fontsize=12)
    plt.xlabel('Categories', fontsize=12)

    # הוספת ערכים מעל העמודות
    for i, mean in enumerate(means):
        plt.text(i, mean + stds[i] + 0.1, f'{mean:.2f} ± {stds[i]:.2f}', ha='center', fontsize=10)

    # הצגת הגרף
    plt.tight_layout()
    plt.show()

# פונקציה להצגת מטריצת הקורלציה כגרף 
def plot_correlation_matrix(correlation_matrix):
    if correlation_matrix is None or correlation_matrix.empty:
        print("The correlation matrix is empty or None.")
        return

    # יצירת הגרף
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        correlation_matrix, 
        annot=True,        # הצגת הערכים על הגרף
        cmap='coolwarm',   # צבעים המתאימים לחוזק הקשרים
        fmt=".2f",         # הצגת ערכים עם שתי ספרות אחרי הנקודה
        linewidths=0.5     # עובי הקווים בין התאים
    )
    
    # כותרת לגרף
    plt.title("Correlation Matrix Heatmap", fontsize=16)
    plt.show()


def plot_reward_averages(merged_df):
    if 'financial_reward' not in merged_df.columns or 'social_reward' not in merged_df.columns:
        print("'financial_reward' or 'social_reward' column is missing in the DataFrame.")
        return

    # חישוב ממוצעים
    mean_financial_reward = merged_df['financial_reward'].mean()
    mean_social_reward = merged_df['social_reward'].mean()

    # הכנת הנתונים לגרף
    categories = ['Financial Reward', 'Social Reward']
    averages = [mean_financial_reward, mean_social_reward]

    # יצירת גרף עמודות
    plt.figure(figsize=(8, 5))
    plt.bar(categories, averages, color=['blue', 'green'])
    
    # הוספת כותרות וצירים
    plt.title('Average Rewards', fontsize=16)
    plt.ylabel('Average Value', fontsize=12)
    plt.xlabel('Reward Type', fontsize=12)
    
    # הוספת ערכים מעל העמודות
    for i, value in enumerate(averages):
        plt.text(i, value + 0.05, f'{value:.2f}', ha='center', fontsize=10)

    # הצגת הגרף
    plt.show()


