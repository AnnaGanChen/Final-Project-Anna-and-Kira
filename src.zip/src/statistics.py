import pandas as pd
import numpy as np

# פונקציה לקרוא את הנתונים
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t') #בגלל שהקבצים מוסיפה tsv 
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

#AQ שאלון 
# פונקציה לחישוב הניקוד הסופי
def calculate_aq_score(df):
    # הגדרת עמודות חיוביות ושליליות
    positive_columns = ["aq_2", "aq_4", "aq_5", "aq_6", "aq_7", "aq_9", "aq_12", "aq_13", "aq_16", "aq_18", "aq_19",
                        "aq_20", "aq_21", "aq_22", "aq_23", "aq_26", "aq_33", "aq_35", "aq_39", "aq_41", "aq_42",
                        "aq_43", "aq_45", "aq_46"]

    negative_columns = ["aq_1", "aq_3", "aq_8", "aq_10", "aq_11", "aq_14", "aq_15", "aq_17", "aq_24", "aq_25", "aq_27",
                        "aq_28", "aq_29", "aq_30", "aq_31", "aq_32", "aq_34", "aq_36", "aq_37", "aq_38", "aq_40", "aq_44",
                        "aq_47", "aq_48", "aq_49", "aq_50"]

    # ווידאוי  שהעמודות קיימות
    missing_positive = [col for col in positive_columns if col not in df.columns]
    missing_negative = [col for col in negative_columns if col not in df.columns]
    
    if missing_positive or missing_negative:
        print(f"Missing columns: Positive - {missing_positive}, Negative - {missing_negative}")
        return None

    # חישוב ניקוד חיובי
    df[positive_columns] = df[positive_columns].apply(lambda x: x.map(lambda v: 1 if v in [0, 1] else 0))

    # חישוב ניקוד שלילי
    df[negative_columns] = df[negative_columns].apply(lambda x: x.map(lambda v: 1 if v in [3, 4] else 0))

    # חישוב הניקוד הסופי
    df["Final_aq_score"] = df[positive_columns].sum(axis=1) + df[negative_columns].sum(axis=1)

    return df[["participant_id", "Final_aq_score"]]

#  קריאה לפונקציות
file_path = r'phenotype/autism_quotient.tsv'
dfaq = load_data(file_path)  # טוען את הנתונים

if dfaq is not None:
    result = calculate_aq_score(dfaq)  # מחשב את הניקוד הסופי, מימוש 
    if result is not None:
        print(result.head())



def categorize_and_group(dfaq):
    # לסווג לקבוצות בלהתבסס למעל או מתחת ל25
    dfaq["Group"] = dfaq["Final_aq_score"].apply(lambda x: "Clinical" if x > 25 else "Non-Clinical")
    
    # לבצע הערכה של מדיי מרכז 
    grouped = dfaq.groupby("Group")["Final_aq_score"].agg(["count", "mean", "std"])
    
    return grouped

grouped_statistics = categorize_and_group(dfaq)
print(grouped_statistics)


# שאלון  altman data
file_path_altman = r'phenotype/altman_self_rating_mania_scale.tsv'
dfmania = load_data(file_path_altman)

if dfmania is not None:
    print(dfmania.columns)

def fill_missing_values(df, columns):
    df[columns] = df[columns].fillna(0)
    return df

# פונקציה להסרת שורות עם ערכים חסרים בעמודות מסוימות
def drop_na_in_columns(df, columns):
    df = df.dropna(subset=columns)
    return df

# פונקציה להמיר את הערכים בעמודות למספריים
def convert_columns_to_numeric(df, columns):
    df[columns] = df[columns].apply(pd.to_numeric, errors="coerce")
    return df

# פונקציה לחשב את סך התשובות עבור כל משתתף
def calculate_sum_of_answers(df, columns):
    df["answers_altman_sum"] = df[columns].sum(axis=1)
    return df

# פונקציה לקביעת הקבוצה (Clinical / Non-Clinical) לפי סכום התשובות
def categorize_group(df):
    df["Group"] = df["answers_altman_sum"].apply(lambda x: "Clinical" if x > 6 else "Non-Clinical")
    return df

# פונקציה לחישוב מדדים סטטיסטיים לקבוצות
def get_group_statistics(df):
    grouped = df.groupby("Group")["answers_altman_sum"].agg(["count", "mean", "std"])
    return grouped

# פונקציה לסיכום התוצאות הסופיות (משתתף, סכום תשובות, קבוצה)
def get_final_results(df):
    return df[["participant_id", "answers_altman_sum", "Group"]]

# פונקציה שמבצעת את כל תהליך עבור השאלון 
def process_altman_data(df, answers_columns):
    # ביצוע כל שלב בתהליך
    df = fill_missing_values(df, answers_columns)
    df = drop_na_in_columns(df, answers_columns)
    df = convert_columns_to_numeric(df, answers_columns)
    df = calculate_sum_of_answers(df, answers_columns)
    result_mania_sum = df[["participant_id", "answers_altman_sum"]]
    df = categorize_group(df)
    grouped = get_group_statistics(df)
    results_altman_final = get_final_results(df)
    
    # חזרה עם תוצאות ממוקדות
    return result_mania_sum, grouped, results_altman_final

file_path_altman = r'phenotype/altman_self_rating_mania_scale.tsv'
dfmania = load_data(file_path_altman)

if dfmania is not None:
    answers_altman = ["asrm_q1", "asrm_q2", "asrm_q3", "asrm_q4", "asrm_q5"]
    result_mania_sum, grouped, results_altman_final = process_altman_data(dfmania, answers_altman)

    print(result_mania_sum.head())
    print(grouped)
    print(results_altman_final.head())

#AADIS שאלון 
dfaadispath = r'phenotype/adolescent_alcohol_and_drug_involvement_scale.tsv'
dfaadis = load_data(dfaadispath)

# הצגת השורות הראשונות אם הנתונים נטענו בהצלחה
if dfaadis is not None:
    print(dfaadis.head())
else:
    print("Can't load a data")

def process_aadis_data(dfaadis):
    # הגדרת השאלות שצריכים לעבור עיבוד
    answers_aadis = ["aadis_q1", "aadis_q2", "aadis_q3", "aadis_q4", "aadis_q5", "aadis_q6", "aadis_q7", "aadis_q8",
                     "aadis_q9", "aadis_q10", "aadis_q11", "aadis_q12", "aadis_q13"]
    
    # המרת הערכים לעמודות מספריות (עם טיפול בערכים חסרים)
    dfaadis[answers_aadis] = dfaadis[answers_aadis].apply(pd.to_numeric, errors="coerce")
    
    # חישוב סך התשובות
    dfaadis["Answers_aadis_sum"] = dfaadis[answers_aadis].sum(axis=1)
    
    # יצירת DataFrame עם participant_id ו Answers_aadis_sum
    aadis_sum = dfaadis[["participant_id", "Answers_aadis_sum"]]
    
    # החזרת התוצאה
    return aadis_sum


if dfaadis is not None:
    aadis_sum = process_aadis_data(dfaadis)
    print(aadis_sum.head())  # הצגת השורות הראשונות של התוצאה
else:
    print("Can't load a data")


def group_aadis_by_sum(df):
    # יצירת העמודה Group בהתבסס על Answers_aadis_sum
    dfaadis["Group"] = dfaadis["Answers_aadis_sum"].apply(
        lambda x: "Non-Clinical" if x < 1 else
                  "Clinical" if 1 <= x < 37 else  # מהמאמר 
                  "Clinical"
    )
    
    # חישוב סטטיסטיקות לפי קבוצות
    grouped_aadis = dfaadis.groupby("Group")["Answers_aadis_sum"].agg(["count", "mean", "std"])
    
    return grouped_aadis

if dfaadis is not None:
    grouped_aadis = group_aadis_by_sum(dfaadis)
    print(grouped_aadis)  # הצגת התוצאה
else:
    print("Can't load a data")

#שאלון BECKS DEPRESSION 
dfbdipath = r'phenotype/becks_depression_inventory.tsv'
dfbdi = load_data(dfbdipath)

# האם דאטה ירד בהצלחה 
if dfbdi is not None:
    print(dfbdi.head())  


def process_bdi_data(file_path):
    answers_bdi = [
        "bdi_q1", "bdi_q2", "bdi_q3", "bdi_q4", "bdi_q5", "bdi_q6", "bdi_q7", "bdi_q8", "bdi_q9", "bdi_q10",
        "bdi_q11", "bdi_q12", "bdi_q13", "bdi_q14", "bdi_q15", "bdi_q16", "bdi_q17", "bdi_q18", "bdi_q19",
        "bdi_q20", "bdi_q21"
    ]
    
    # משיכה מהפונקציה הקיימת 
    dfbdi = load_data(file_path)
    
    if dfbdi is not None:
        # טיפול בערכים חסרים 
        dfbdi[answers_bdi] = dfbdi[answers_bdi].fillna(0)
        dfbdi = dfbdi.dropna(subset=answers_bdi)
        
        # העברה לערכים מספריים
        dfbdi[answers_bdi] = dfbdi[answers_bdi].apply(pd.to_numeric, errors="coerce")
        
        # לחשב סכום של תשובות
        dfbdi["answers_bdi_sum"] = dfbdi[answers_bdi].sum(axis=1)
        
        #להציג את התוצאות 
        result_bdi_sum = dfbdi[["participant_id", "answers_bdi_sum"]]
        
        return result_bdi_sum
    else:
        print("Error: Data not loaded.")
        return None


def process_bdi_groups(df):
    # חלוקה לפי הקבוצות (לפי המאמר)
    df["Group"] = df["answers_bdi_sum"].apply(
        lambda x: "Non-Clinical" if x < 13 else
                  "Non-Clinical" if 14 <= x < 19 else
                  "Clinical" if 20 <= x < 28 else
                  "Clinical"
    )
    
    # בדיקה ערכים סטטיסטיסיים 
    grouped_bdi = df.groupby("Group")["answers_bdi_sum"].agg(["count", "mean", "std"])
    
    #לעשות עמודה סופית 
    final_table_bdi = df[["participant_id", "answers_bdi_sum", "Group"]]

    return grouped_bdi, final_table_bdi


#BEHAVIORAL INHIBITION/ACTIVATION SCALE שאלון 
dfbisbaspath = r'phenotype/behavioral_inhibition_scale_behavioral_activation_scale.tsv'
dfbisbas = load_data(dfbisbaspath)

# הצגת מספר שורות ראשונות של הנתונים
if dfbisbas is not None:
    print(dfbisbas.head())

def calculate_bisbas_sum(dfbisbas, all_answers_bisbas): #פונקציה לחישוב סכום של כל התשובות 
    dfbisbas[all_answers_bisbas] = dfbisbas[all_answers_bisbas].fillna(0)
    dfbisbas = dfbisbas.dropna(subset=all_answers_bisbas)
    dfbisbas[all_answers_bisbas] = dfbisbas[all_answers_bisbas].apply(pd.to_numeric, errors="coerce")
    dfbisbas["all_answers_bisbas_sum"] = dfbisbas[all_answers_bisbas].sum(axis=1)
    return dfbisbas[["participant_id", "all_answers_bisbas_sum"]]

def reverse_bisbas_columns(dfbisbas, reverse_columns): #להפוך את השאלות 
    dfbisbas[reverse_columns] = dfbisbas[reverse_columns].applymap(lambda x: 5 - x)
    return dfbisbas

def calculate_group_sums(dfbisbas, group_columns): #חישוב סכום לפי קבוצות 
    for group, columns in group_columns.items():
        dfbisbas[f"{group}_sum"] = dfbisbas[columns].sum(axis=1)
    return dfbisbas

def create_groups(dfbisbas): #יצירת קבוצות 
    # Punishment group
    dfbisbas["bisbas_punishment_group"] = dfbisbas["Punishment_sensitivity_sum"].apply(
        lambda x: "Low punishment sensitivity" if x < 20 else "High punishment sensitivity")

    # Reward group
    dfbisbas["bisbas_reward_group"] = dfbisbas["Reward_responsiveness_sum"].apply(
        lambda x: "Low reward responsiveness" if x < 17 else "High reward responsiveness")

    # Drive group
    dfbisbas["bisbas_drive_group"] = dfbisbas["Bisbas_drive_sum"].apply(lambda x: "Low drive" if x < 11 else "High drive")

    # Fun-seeking group
    dfbisbas["bisbas_fun_seeking_group"] = dfbisbas["fun_seeking_sum"].apply(
        lambda x: "Low fun seeking" if x < 12 else "High fun seeking")

    return dfbisbas

def describe_groups(dfbisbas):#תיאור הקבוצות 
    return dfbisbas[["Punishment_sensitivity_sum", "Reward_responsiveness_sum", "Bisbas_drive_sum", "fun_seeking_sum"]].describe().T

def group_summary(dfbisbas, group_column, sum_column): #סיכום קבוצות 
    return dfbisbas.groupby(group_column)[sum_column].agg(["count", "mean", "std"])

def create_final_table(dfbisbas): #טבלה סופית 
    return dfbisbas[["participant_id", "bisbas_fun_seeking_group", "bisbas_drive_group", "bisbas_reward_group", "bisbas_punishment_group"]]

#BUSS PERRY AGRESSION שאלון 
dfbpaqpath = r'phenotype/buss_perry_aggression_questionnaire.tsv'
dfbpaq = load_data(dfbpaqpath)

if dfbpaq is not None:
    print(dfbpaq.head())


def process_bpaq_data(df, reverse_columns, reverse_score_bpaq, bpaq_answers):
    #להפוך ניקוד 
    df[reverse_columns] = df[reverse_columns].applymap(lambda x: 5 - x)
    df[reverse_score_bpaq] = df[reverse_score_bpaq].applymap(lambda x: 6 - x)

    # למלא ערכים חסרים 
    df[bpaq_answers] = df[bpaq_answers].fillna(0)
    df = df.dropna(subset=bpaq_answers)
    df[bpaq_answers] = df[bpaq_answers].apply(pd.to_numeric, errors="coerce")

    # עמודה של ציון הסופי 
    df["bpaq_answers_sum"] = df[bpaq_answers].sum(axis=1)

    # חלוקה לקליני/לא קליני לפי המאמר 
    df["Group"] = df["bpaq_answers_sum"].apply(
        lambda x: "Non-Clinical" if x < 64.9 else "Clinical"
    )

    # לעשות מדדי מרכז 
    grouped_bpaq = df.groupby("Group")["bpaq_answers_sum"].agg(["count", "mean", "median", "std"])

    # הדפס עמוד הסופית 
    final_table = df[["participant_id", "bpaq_answers_sum", "Group"]]

    return final_table, grouped_bpaq

# כדי למממש את הפונקציה, הגדרת משתנים 
reverse_columns = ["bpaq_q7", "bpaq_q18"]
reverse_score_bpaq = ["bpaq_q7", "bpaq_q18"]
bpaq_answers = ["bpaq_q1", "bpaq_q2", "bpaq_q3", "bpaq_q4", "bpaq_q5", "bpaq_q6", "bpaq_q7", "bpaq_q8", "bpaq_q9",
                "bpaq_q10", "bpaq_q11", "bpaq_q12", "bpaq_q13", "bpaq_q14", "bpaq_q15", "bpaq_q16", "bpaq_q17",
                "bpaq_q18", "bpaq_q19", "bpaq_q20", "bpaq_q21", "bpaq_q22", "bpaq_q23", "bpaq_q24", "bpaq_q25",
                "bpaq_q26", "bpaq_q27", "bpaq_q28", "bpaq_q29"]

# מימוש פונקציה 
final_table, grouped_stats = process_bpaq_data(dfbpaq, reverse_columns, reverse_score_bpaq, bpaq_answers)
print(final_table.head())
print(grouped_stats)

#שאלון CHILDHOOD TRAUMA
dfctqsfpath = r'phenotype/childhood_trauma_questionnaire_short_form.tsv'
dfctqsf = load_data(dfctqsfpath)

# הצגת השורות הראשונות אם הקריאה הצליחה
if dfctqsf is not None:
    print(dfctqsf.head())

def preprocess_ctqsf(dfctqsf, reverse_columns, denial_columns, all_answers_columns):
    # הפיכת הערכים בעמודות ההיפוך
    dfctqsf[reverse_columns] = dfctqsf[reverse_columns].applymap(lambda x: 6 - x)

    # עיבוד עמודות ההכחשה
    dfctqsf[denial_columns] = dfctqsf[denial_columns].applymap(lambda x: 1 if x == 5 else 0)
    dfctqsf["denial_columns_sum"] = dfctqsf[denial_columns].sum(axis=1)

    # מילוי ערכים חסרים בעמודות השאלון
    dfctqsf[all_answers_columns] = dfctqsf[all_answers_columns].fillna(0)
    dfctqsf = dfctqsf.dropna(subset=all_answers_columns)

    # המרה לערכים נומריים
    dfctqsf[all_answers_columns] = dfctqsf[all_answers_columns].apply(pd.to_numeric, errors="coerce")

    return dfctqsf

def calculate_ctqsf_sums(dfctqsf, all_answers_columns):
    dfctqsf["all_answers_ctqsf_sum"] = dfctqsf[all_answers_columns].sum(axis=1)
    result = dfctqsf[["participant_id", "all_answers_ctqsf_sum", "denial_columns_sum"]]
    return result

reverse_columns = ["ctqsf_adult_cj_2"]
denial_columns = ["ctqsf_adult_cj_10", "ctqsf_adult_cj_16", "ctqsf_adult_cj_22"]
all_answers_columns = [
    "ctqsf_adult_cj_1", "ctqsf_adult_cj_2", "ctqsf_adult_cj_3", "ctqsf_adult_cj_4", "ctqsf_adult_cj_5",
    "ctqsf_adult_cj_6", "ctqsf_adult_cj_7", "ctqsf_adult_cj_8", "ctqsf_adult_cj_9", "ctqsf_adult_cj_11",
    "ctqsf_adult_cj_12", "ctqsf_adult_cj_13", "ctqsf_adult_cj_14", "ctqsf_adult_cj_15", "ctqsf_adult_cj_17",
    "ctqsf_adult_cj_18", "ctqsf_adult_cj_19", "ctqsf_adult_cj_20", "ctqsf_adult_cj_21", "ctqsf_adult_cj_23",
    "ctqsf_adult_cj_24", "ctqsf_adult_cj_25", "ctqsf_adult_cj_26", "ctqsf_adult_cj_27", "ctqsf_adult_cj_28"
]



def clean_and_sum(dfctqsf, columns, sum_column_name):

    dfctqsf[columns] = dfctqsf[columns].fillna(0)
    
    dfctqsf = dfctqsf.dropna(subset=columns)
    
    dfctqsf[sum_column_name] = dfctqsf[columns].sum(axis=1)
    
    return dfctqsf

def group_by_threshold(dfctqsf, column_name, threshold, group_name):
    dfctqsf["Group"] = dfctqsf[column_name].apply(lambda x: group_name if x >= threshold else "Non-Clinical")
    return dfctqsf

def group_and_agg(dfctqsf, column_name):
    return dfctqsf.groupby("Group")[column_name].agg(["count", "mean", "median", "std"])

def combine_abuse_and_neglect(dfctqsf, emotional_abuse, physical_abuse, sexual_abuse, emotional_neglect, physical_neglect):
    # ניקוד של תתי קטגוריות 
    df = clean_and_sum(dfctqsf, emotional_abuse, "Emotional_abuse_sum")
    df = clean_and_sum(dfctqsf, physical_abuse, "Physical_abuse_sum")
    df = clean_and_sum(dfctqsf, sexual_abuse, "Sexual_abuse_sum")
    df = clean_and_sum(dfctqsf, emotional_neglect, "Emotional_neglect_sum")
    df = clean_and_sum(dfctqsf, physical_neglect, "Physical_neglect_sum")
    
    return df

def apply_grouping_and_agg(dfctqsf, thresholds):
    #בשביל מימוש לפי קטגוריות כלליות
    grouped_results = {} #הגדרת מילון 
    categories = {
        "Emotional_abuse_sum": thresholds['emotional_abuse'],
        "Physical_abuse_sum": thresholds['physical_abuse'],
        "Sexual_abuse_sum": thresholds['sexual_abuse'],
        "Emotional_neglect_sum": thresholds['emotional_neglect'],
        "Physical_neglect_sum": thresholds['physical_neglect']
    } #מילון שמגדיר קשר בין שמות העמודות בטבלה לבין המספרים הרלוונטיים 

    for column_name, threshold in categories.items(): #לולאה לחילוק לקטגוריות 
        dfctqsf = group_by_threshold(dfctqsf, column_name, threshold, column_name.replace('_sum', '').replace('_', ' ').title())
        grouped_results[column_name] = group_and_agg(dfctqsf, column_name) #מופעלת על ידי משתנה dfctqsf, המטרה לעשות עמודה חדשה בהתאם לשיוך של ערכים לקבוצה 
    
    return grouped_results #מטרה לשייך ציון של סכום לעמודות 

def main(dfctqsf, emotional_abuse, physical_abuse, sexual_abuse, emotional_neglect, physical_neglect, thresholds):
#חלוקה לפי קטגוריות  
    dfctqsf = combine_abuse_and_neglect(dfctqsf, emotional_abuse, physical_abuse, sexual_abuse, emotional_neglect, physical_neglect)

    # מימוש 
    grouped_results = apply_grouping_and_agg(dfctqsf, thresholds)
    
    # חלוקה לקליני/לא קליני
    ctqsf_clinical_nonclinical = dfctqsf[["participant_id", "Group"]]
    
    return dfctqsf, grouped_results, ctqsf_clinical_nonclinical


#DRUG USE DISORDER שאלון 
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t')
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# נתיב הקובץ
dfduditfpath = r'phenotype/drug_use_disorders_identification_test.tsv'

# קריאה לפונקציה עם הנתיב של הקובץ
dfdudit = load_data(dfduditfpath)

# אם הפונקציה הצליחה להחזיר את הדאטה פריים, הדפס את 5 השורות הראשונות
if dfdudit is not None:
    print(dfdudit.head())

def process_dudit_data(dfdudit):
    # רשימת השאלות בדודיט
    dudit_answers = ["dudit_1", "dudit_2", "dudit_3", "dudit_4", "dudit_5", "dudit_6", "dudit_7", "dudit_8", "dudit_9",
                     "dudit_10", "dudit_11"]

    # מילוי ערכים חסרים ב-0 והסרת שורות עם ערכים חסרים
    dfdudit[dudit_answers] = dfdudit[dudit_answers].fillna(0)
    dfdudit = dfdudit.dropna(subset=dudit_answers)

    # המרת הערכים לפורמט נומרי
    dfdudit[dudit_answers] = dfdudit[dudit_answers].apply(pd.to_numeric, errors="coerce")

    # חישוב סכום התשובות לכל משתתף
    dfdudit["dudit_answers_sum"] = dfdudit[dudit_answers].sum(axis=1)

    # יצירת DataFrame עם מזהה המשתתף וסכום התשובות
    result_dudit_sum = dfdudit[["participant_id", "dudit_answers_sum"]]

    # הגדרת הקבוצה על פי סכום התשובות
    dfdudit["Group"] = dfdudit["dudit_answers_sum"].apply(
        lambda x: "Clinical" if x >= 25 else "Non-Clinical")

    # קבוצת התפלגות סכום התשובות לפי קבוצות (Clinical/Non-Clinical)
    grouped_drug_dependance = dfdudit.groupby("Group")["dudit_answers_sum"].agg(["count", "mean", "median", "std"])

    # יצירת DataFrame עם מזהה המשתתף, הקבוצה וסכום התשובות
    Drug_dependancy_table = dfdudit[["participant_id", "Group", "dudit_answers_sum"]]

    return result_dudit_sum, grouped_drug_dependance, Drug_dependancy_table


#personal norms of reciprocity שאלון 
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t')
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# נתיב הקובץ
dfpnrfpath = r'phenotype/personal_norms_of_reciprocity.tsv'
# קריאה לפונקציה עם הנתיב של הקובץ
dfpnr = load_data(dfpnrfpath)

def process_pnr_data(file_path):
    # קריאה לפונקציה load_data כדי לטעון את הנתונים
    dfpnr = load_data(file_path)
    
    # אם טעינת הקובץ הצליחה
    if dfpnr is not None:
        # רשימת השאלות של PNR
        pnr_questions = ["pnr_q1", "pnr_q2", "pnr_q3", "pnr_q4", "pnr_q5", "pnr_q6", "pnr_q7", "pnr_q8", "pnr_q9"]
        
        # מילוי ערכים חסרים ב-0 והסרת שורות עם ערכים חסרים
        dfpnr[pnr_questions] = dfpnr[pnr_questions].fillna(0)
        dfpnr = dfpnr.dropna(subset=pnr_questions)

        # המרת הערכים לפורמט נומרי
        dfpnr[pnr_questions] = dfpnr[pnr_questions].apply(pd.to_numeric, errors="coerce")

        # חישוב סכום התשובות לכל משתתף
        dfpnr["pnr_answers_sum"] = dfpnr[pnr_questions].sum(axis=1)

        # יצירת DataFrame עם מזהה המשתתף וסכום התשובות
        result_pnr_sum = dfpnr[["participant_id", "pnr_answers_sum"]]

        # חישוב ממוצע התשובות
        mean_pnr = dfpnr["pnr_answers_sum"].mean()

        # הגדרת הקבוצה על פי סכום התשובות
        dfpnr["Group"] = dfpnr["pnr_answers_sum"].apply(
            lambda x: "Clinical" if x >= 21 else "Non-Clinical")

        # קבוצת התפלגות סכום התשובות לפי קבוצות (Clinical/Non-Clinical)
        grouped_negative_r = dfpnr.groupby("Group")["pnr_answers_sum"].agg(["count", "mean", "median", "std"])

        # יצירת DataFrame עם מזהה המשתתף, הקבוצה וסכום התשובות
        Reciprocity_table = dfpnr[["participant_id", "Group", "pnr_answers_sum"]]

        # החזרת התוצאות
        return result_pnr_sum, mean_pnr, grouped_negative_r, Reciprocity_table


#positive valence system survey שאלון 
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t')
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# נתיב הקובץ
dfpvssfpath = r'phenotype/positive_valence_systems_survey.tsv'
dfpvss = load_data(dfpvssfpath)
def process_pvss_data(file_path):
    # קריאה לפונקציה load_data כדי לטעון את הנתונים
    dfpvss = load_data(file_path)
    
    # אם טעינת הקובץ הצליחה
    if dfpvss is not None:
        # רשימת השאלות של PVSS
        pvss_questions = ["pvss_q1", "pvss_q2", "pvss_q3", "pvss_q4", "pvss_q5", "pvss_q6", "pvss_q7", "pvss_q8", "pvss_q9",
                          "pvss_q10", "pvss_q11", "pvss_q12", "pvss_q13", "pvss_q14", "pvss_q15", "pvss_q16", "pvss_q17",
                          "pvss_q18", "pvss_q19", "pvss_q20", "pvss_q21"]

        # הפיכת הציונים - שאלות עם ציונים הפוכי)
        dfpvss[pvss_questions] = dfpvss[pvss_questions].map(lambda x: 10 - x)

        # מילוי ערכים חסרים ב-0 והסרת שורות עם ערכים חסרים
        dfpvss[pvss_questions] = dfpvss[pvss_questions].fillna(0)
        dfpvss = dfpvss.dropna(subset=pvss_questions)

        # המרת הערכים לפורמט נומרי
        dfpvss[pvss_questions] = dfpvss[pvss_questions].apply(pd.to_numeric, errors="coerce")

        # חישוב סכום התשובות לכל משתתף
        dfpvss["pvss_answers_sum"] = dfpvss[pvss_questions].sum(axis=1)

        # יצירת DataFrame עם מזהה המשתתף וסכום התשובות
        result_pvss_sum = dfpvss[["participant_id", "pvss_answers_sum"]]

        # חישוב ממוצע התשובות
        mean_pvss = dfpvss["pvss_answers_sum"].mean()

        # החזרת התוצאות
        return result_pvss_sum, mean_pvss
    

#שאלון unpredictability in childhood
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t')
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# נתיב הקובץ
dfquicfpath = r'phenotype/questionnaire_of_unpredictability_in_childhood.tsv'
dfquic = load_data(dfquicfpath)

def reverse_columns(dfquic, columns):
    dfquic[columns] = dfquic[columns].map(lambda x: 1 - x)
    return dfquic

def fill_and_convert(dfquic, columns):
    dfquic[columns] = dfquic[columns].fillna(0)
    dfquic[columns] = dfquic[columns].apply(pd.to_numeric, errors="coerce")
    return dfquic
def calculate_sum(dfquic, columns):
    dfquic["answers_sum"] = dfquic[columns].sum(axis=1)
    return dfquic
def assign_groups(dfquic, threshold=6):
    dfquic["Group"] = dfquic["answers_sum"].apply(lambda x: "Clinical" if x >= threshold else "Non-Clinical")
    return dfquic

def process_quic_data(df, reverse_columns_quic, quic_questions, threshold=6):
    # הפיכת הציונים בעמודות שנדרשות
    df = reverse_columns(df, reverse_columns_quic)
    
    # מילוי ערכים חסרים והמרת הערכים לפורמט נומרי
    df = fill_and_convert(df, quic_questions)
    
    # חישוב סכום התשובות
    df = calculate_sum(df, quic_questions)
    
    # קביעת הקבוצות (Clinical/Non-Clinical)
    df = assign_groups(df, threshold)
    
    # יצירת טבלה עם מזהה המשתתף וסכום התשובות
    result_quic_sum = df[["participant_id", "answers_sum"]]
    
    # חישוב ממוצע התשובות
    mean_quic = df["answers_sum"].mean()
    
    # קבוצת התפלגות סכום התשובות לפי קבוצות
    grouped_quic = df.groupby("Group")["answers_sum"].agg(["count", "mean", "median", "std"])
    
    return result_quic_sum, mean_quic, grouped_quic

#R. self esteem שאלון 
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t')
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# נתיב הקובץ
dfrsefpath = r'phenotype/rosenberg_self_esteem.tsv'
dfrse = load_data(dfrsefpath)


def process_self_esteem_data(dfrse):
    #להפוך שאלות 
    reverse_r_score = ["rse_q1", "rse_q2", "rse_q4", "rse_q6", "rse_q7"]
    dfrse[reverse_r_score] = dfrse[reverse_r_score].map(lambda x: 5 - x)

    # לעשות משתנים של כל התשובות 
    R_self_esteem_questions = ["rse_q1", "rse_q2", "rse_q3", "rse_q4", "rse_q5", "rse_q6", "rse_q7", "rse_q8", 
                               "rse_q9", "rse_q10"]

    # ניקוי דאטה 
    dfrse[R_self_esteem_questions] = dfrse[R_self_esteem_questions].fillna(0)
    dfrse = dfrse.dropna(subset=R_self_esteem_questions)

    #להעביר למספרים שלמים 
    dfrse[R_self_esteem_questions] = dfrse[R_self_esteem_questions].apply(pd.to_numeric, errors="coerce")

    # לעשות עמודה לערך עצמי
    dfrse["R_self_esteem_sum"] = dfrse[R_self_esteem_questions].sum(axis=1)

    #קבלת תוצאה 
    result_rse_sum = dfrse[["participant_id", "R_self_esteem_sum"]]

    # ממוצע
    mean_rse = dfrse["R_self_esteem_sum"].mean()

    # חלוקה לפי ממוצע 
    dfrse["Group"] = dfrse["R_self_esteem_sum"].apply(lambda x: "Non-Clinical" if x >= 26 else "Clinical")

    # לעשות ממדי מרכז 
    grouped_rse = dfrse.groupby("Group")["R_self_esteem_sum"].agg(["count", "mean", "median", "std"])

    # עמודה סופית 
    Rse_final_table = dfrse[["participant_id", "Group", "R_self_esteem_sum"]]

    return result_rse_sum, mean_rse, grouped_rse, Rse_final_table

#sensitivity to punishment/reward שאלון 
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t')
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# נתיב הקובץ
dfspsrqfpath = r'phenotype/sensitivity_to_punishment_sensitivity_to_reward_questionnaire.tsv'
dfspsrq = load_data(dfspsrqfpath)

def calculate_punishment_spsrq(dfspsrq, Punishment_spsrq_q):
    # מילוי ערכים חסרים ב-0
    dfspsrq[Punishment_spsrq_q] = dfspsrq[Punishment_spsrq_q].fillna(0)
    
    # מחיקת שורות עם ערכים חסרים בעמודות שנבחרו
    dfspsrq = dfspsrq.dropna(subset=Punishment_spsrq_q)
    
    # המרת הערכים לאופציה מספרית
    dfspsrq[Punishment_spsrq_q] = dfspsrq[Punishment_spsrq_q].apply(pd.to_numeric, errors="coerce")
    
    # חישוב הסכום של העונש עבור כל שורה
    dfspsrq["Punishment_spsrq_sum"] = dfspsrq[Punishment_spsrq_q].sum(axis=1)
    
    # יצירת קבוצות עונש על פי ממוצע
    dfspsrq["Punishment_spsrq_groups"] = dfspsrq["Punishment_spsrq_sum"].apply(
        lambda x: "High punishment sensitivity" if x >= 14 else "Low punishment sensitivity"
    )
    
    # קיבוץ על פי קבוצות עם חישוב מדדים סטטיסטיים
    grouped_punishment_spsrq = dfspsrq.groupby("Punishment_spsrq_groups")["Punishment_spsrq_sum"].agg(
        ["count", "mean", "median", "std"]
    )
    
    return dfspsrq, grouped_punishment_spsrq

# פונקציה לחישוב סכום פרס ויצירת קבוצות על פי ערך ממוצע
def calculate_reward_spsrq(dfspsrq, Reward_spsrq_q):
    # מילוי ערכים חסרים ב-0
    dfspsrq[Reward_spsrq_q] = dfspsrq[Reward_spsrq_q].fillna(0)
    
    # מחיקת שורות עם ערכים חסרים בעמודות שנבחרו
    dfspsrq = dfspsrq.dropna(subset=Reward_spsrq_q)
    
    # המרת הערכים לאופציה מספרית
    dfspsrq[Reward_spsrq_q] = dfspsrq[Reward_spsrq_q].apply(pd.to_numeric, errors="coerce")
    
    # חישוב הסכום של הפרס עבור כל שורה
    dfspsrq["Reward_spsrq_sum"] = dfspsrq[Reward_spsrq_q].sum(axis=1)
    
    # יצירת קבוצות פרס על פי ממוצע
    dfspsrq["Reward_spsrq_groups"] = dfspsrq["Reward_spsrq_sum"].apply(
        lambda x: "High Reward sensitivity" if x >= 12.2 else "Low Reward sensitivity"
    )
    
    # קיבוץ על פי קבוצות עם חישוב מדדים סטטיסטיים
    grouped_reward_spsrq = dfspsrq.groupby("Reward_spsrq_groups")["Reward_spsrq_sum"].agg(
        ["count", "mean", "median", "std"]
    )
    
    return dfspsrq, grouped_reward_spsrq

# פונקציה סופית להחזרת הטבלה הסופית
def generate_spsrq_final_table(dfspsrq):
    # יצירת טבלה סופית עם העמודות הרצויות
    Spsrq_final_table = dfspsrq[["participant_id", "Reward_spsrq_groups", "Reward_spsrq_sum", "Punishment_spsrq_groups",
                                 "Punishment_spsrq_sum"]]
    return Spsrq_final_table

# פונקציה מרכזית שמחברת את כל החישובים
def process_spsrq_data(dfspsrq, Punishment_spsrq_q, Reward_spsrq_q):
    # חישוב עונש
    dfspsrq, grouped_punishment_spsrq = calculate_punishment_spsrq(dfspsrq, Punishment_spsrq_q)
    
    # חישוב פרס
    dfspsrq, grouped_reward_spsrq = calculate_reward_spsrq(dfspsrq, Reward_spsrq_q)
    
    # יצירת טבלה סופית
    Spsrq_final_table = generate_spsrq_final_table(dfspsrq)
    
    return Spsrq_final_table, grouped_punishment_spsrq, grouped_reward_spsrq





def process_mania_data(df, mania_questions, mania_threshold=3.7):
   
    df[mania_questions] = df[mania_questions].fillna(0)
    df = df.dropna(subset=mania_questions)
    df[mania_questions] = df[mania_questions].apply(pd.to_numeric, errors="coerce")
    df["susd_mania_sum"] = df[mania_questions].sum(axis=1)
    
    df["mania_group"] = df["susd_mania_sum"].apply(lambda x: "Clinical" if x >= mania_threshold else "Non-Clinical")
    
    grouped_mania = df.groupby("mania_group")["susd_mania_sum"].agg(["count", "mean", "median", "std"])
    
    return df[["participant_id", "susd_mania_sum"]], grouped_mania


def process_depression_data(df, depression_questions, depression_threshold=4.3):
    
    df[depression_questions] = df[depression_questions].fillna(0)
    df = df.dropna(subset=depression_questions)
    df[depression_questions] = df[depression_questions].apply(pd.to_numeric, errors="coerce")
    df["susd_depression_sum"] = df[depression_questions].sum(axis=1)
    
    df["depression_group"] = df["susd_depression_sum"].apply(lambda x: "Clinical" if x >= depression_threshold else "Non-Clinical")
    
    grouped_depression = df.groupby("depression_group")["susd_depression_sum"].agg(["count", "mean", "median", "std"])
    
    return df[["participant_id", "susd_depression_sum"]], grouped_depression


def process_total_score(df, all_questions):
   
    df[all_questions] = df[all_questions].fillna(0)
    df = df.dropna(subset=all_questions)
    df[all_questions] = df[all_questions].apply(pd.to_numeric, errors="coerce")
    df["susd_sum"] = df[all_questions].sum(axis=1)
    
    return df[["participant_id", "susd_sum"]]

#שאלון seven up/down
def load_data(file_path):
    try:
        df = pd.read_csv(file_path, sep='\t')
        return df
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# נתיב הקובץ
dfsusdpath = r'phenotype/seven_up_seven_down.tsv'
dfsusd = load_data(dfsusdpath)
dfsusd.fillna(0, inplace=True)

def process_susd_data(dfsusd):
    mania_questions = ["score_susd_q1", "score_susd_q3", "score_susd_q4", "score_susd_q6", "score_susd_q7", "score_susd_q8", "score_susd_q13"]
    depression_questions = ["score_susd_q2", "score_susd_q5", "score_susd_q9", "score_susd_q10", "score_susd_q11", "score_susd_q12", "score_susd_q14"]
    all_susd_questions = mania_questions + depression_questions
    
    result_susd_mania_sum, grouped_mania_susd = process_mania_data(dfsusd, mania_questions)
    
    result_susd_depression_sum, grouped_depression_susd = process_depression_data(dfsusd, depression_questions)
    
    result_susd_sum = process_total_score(dfsusd, all_susd_questions)
    
    final_table = dfsusd[["participant_id", "mania_group", "susd_depression_sum", "susd_mania_sum", "susd_sum"]]

    return result_susd_mania_sum, grouped_mania_susd, result_susd_depression_sum, grouped_depression_susd, result_susd_sum, final_table


#social experience questionnaire שאלון 
file_path = r'phenotype/social_experience_questionnaire.tsv'
dfseq = load_data(file_path)
if dfseq is not None:
    print("Data loaded successfully!")
else:
    print("Failed to load data.")

def reverse_score_questions(dfseq, questions):
    try:
        # בדיקת קיום עמודות
        missing_columns = [q for q in questions if q not in dfseq.columns]
        if missing_columns:
            raise ValueError(f"The following columns are missing in the DataFrame: {missing_columns}")
        
        # להפוך שאלות 
        for question in questions:
            dfseq[question] = dfseq[question].map(lambda x: 6 - x)
        return dfseq
    except Exception as e:
        print(f"Error processing questions: {e}")
        return dfseq

reverse_seq_questions = ["seq_adult_cj_1", "seq_adult_cj_5", "seq_adult_cj_8", "seq_adult_cj_12", "seq_adult_cj_15"]
dfseq = reverse_score_questions(dfseq, reverse_seq_questions)
print(dfseq)

def process_seq_questions(dfseq, question_columns, participant_column="participant_id"):
    # לנקות ערכים חסרים
    dfseq[question_columns] = dfseq[question_columns].fillna(0)
    # כדי לווקא שהקוד נקי באמת עשינו ניקוי נוסף 
    dfseq = dfseq.dropna(subset=question_columns)
    # העברה למספרים שלמים 
    dfseq[question_columns] = dfseq[question_columns].apply(pd.to_numeric, errors="coerce")
    # חיבור בין העמודות (סיכום)
    dfseq["seq_questions_sum"] = dfseq[question_columns].sum(axis=1)
    # יצירת דאטה פריים חדש עם השינויים שנעשו 
    result_df = dfseq[[participant_column, "seq_questions_sum"]]
    # ממוצע 
    mean_sum = dfseq["seq_questions_sum"].mean()
    return result_df, mean_sum


def process_and_group_by_mean(dfseq, question_sum_column, participant_column="participant_id", threshold=17): #ממוצע זה הtreshold
    #תבדוק האם עמודות של סכום קיימות, אם לא, תיצור עמודות סכום רלוונטיות
    if question_sum_column not in dfseq.columns:
        print(f"{question_sum_column} does not exist. Calculating it now.")
        #  יש עומודות שעושים סיכום נצטרך להגדיר `seq_questions`בהנחה ש  
        seq_questions = [col for col in dfseq.columns if "seq_adult_cj" in col]
        dfseq[question_sum_column] = dfseq[seq_questions].sum(axis=1)
    # תשמש בסף של הממוצע  אם לעמודה אין ציון
    if threshold is None:
        threshold = dfseq[question_sum_column].mean()
    #שמתבססת על הסף  "Group" תוסיף עמודת    
    dfseq["Group"] = dfseq[question_sum_column].apply(
        lambda x: "Clinical" if x >= threshold else "Non-Clinical"
    )
    # לחשב מדדי מרכז "Group" 
    grouped_stats = dfseq.groupby("Group")[question_sum_column].agg(["count", "mean", "median", "std"])
    # לייצר עמודות סופיות 
    final_table = dfseq[[participant_column, "Group", question_sum_column]]
    return grouped_stats, final_table

# מימוש 
grouped_seq_stats, seq_final_table = process_and_group_by_mean(dfseq, "seq_questions_sum")
print(grouped_seq_stats)  # Show group statistics
print(seq_final_table.head())  # Show the final table


#temporal experience of pleasure שאלון 
dftepspath = r'phenotype/temporal_experience_of_pleasure_scale.tsv'
dfteps = load_data(dftepspath)
if dfteps is not None: #אם הדאטה פריים עלה בהצלחה - הצג את השורה הראשונה 
    print(dfteps.head())

reverse_an13 = ["score_teps_q13"]
#reverse_score_questions  קריאת פונקציה שעושה עיבוד של שאלות הפוכות 
dfteps = reverse_score_questions(dfteps, reverse_an13)
print(dfteps.head())


def process_teps_data(dfteps):    
    teps_all_questions = [f"score_teps_q{i}" for i in range(1, 19)] #לולאה שקוראת את כל השאלות 
    # מילוי ערכים חסרים ב-0
    dfteps[teps_all_questions] = dfteps[teps_all_questions].fillna(0)
    # מחיקת שורות שבהן יש ערכים חסרים באחת השאלות
    dfteps = dfteps.dropna(subset=teps_all_questions)
    # המרת הערכים לפורמט נומרי
    dfteps[teps_all_questions] = dfteps[teps_all_questions].apply(pd.to_numeric, errors="coerce")
    # חישוב סכום השאלות לכל משתתף
    dfteps["Teps_questions_sum"] = dfteps[teps_all_questions].sum(axis=1)
    # החזרת תוצאה עם מזהה משתתף וסכום השאלות
    result_teps_sum = dfteps[["participant_id", "Teps_questions_sum"]]
    # החזרת התוצאה הסופית והחישוב של ממוצע הסכום של השאלות
    return result_teps_sum, dfteps["Teps_questions_sum"].mean()

# קריאה לפונקציה 
result_teps_sum, teps_mean = process_teps_data(dfteps)
print(result_teps_sum.head())
print(teps_mean)

    
def process_teps_groups_by_threshold(dfteps, threshold=79, question_sum_column="Teps_questions_sum", participant_column="participant_id"):
    # אם עמודת הסכום לא קיימת, נבצע את החישוב שלה
    if question_sum_column not in dfteps.columns:
        print(f"{question_sum_column} does not exist. Calculating it now.")
        teps_all_questions = [f"score_teps_q{i}" for i in range(1, 19)]  # יצירת רשימה של כל השאלות
        dfteps[question_sum_column] = dfteps[teps_all_questions].sum(axis=1)
    
    # יצירת קבוצות על פי סכום השאלות והסף שניתן
    dfteps["Group"] = dfteps[question_sum_column].apply(
        lambda x: "Non-Clinical" if x < threshold else "Clinical"
    )
    
    # חישוב סטטיסטיקות עבור כל קבוצה
    grouped_stats = dfteps.groupby("Group")[question_sum_column].agg(["count", "mean", "median", "std"])
    
    # החזרת סטטיסטיקות והטבלה הסופית עם מזהה משתתף, קבוצה וסכום השאלות
    final_table = dfteps[[participant_column, "Group", question_sum_column]]
    
    return grouped_stats, final_table

# קריאה לפונקציה
grouped_stats, final_table = process_teps_groups_by_threshold(dfteps)
print(grouped_stats)
print(final_table.head())


#trait emotional intelligence שאלון 
dftei = load_data('phenotype/trait_emotional_intelligence.tsv')
# להראות את העמודה הראשונה
if dftei is not None:
    print(dftei.head())

reverse_tei_question = [
    "tei_q2", "tei_q4", "tei_q5", "tei_q7", "tei_q8", "tei_q10", "tei_q12", "tei_q13", "tei_q14",
    "tei_q16", "tei_q18", "tei_q22", "tei_q25", "tei_q26", "tei_q28"
]
dftei = reverse_score_questions(dftei, reverse_tei_question)
print(dftei[reverse_tei_question].head())


def process_tei_scores(dftei, Tei_questions):
    try:
        # למלא ערכים חסרים 
        dftei[Tei_questions] = dftei[Tei_questions].fillna(0)
        dftei = dftei.dropna(subset=Tei_questions)

        # להעביר לערכים מספריים 
        dftei[Tei_questions] = dftei[Tei_questions].apply(pd.to_numeric, errors="coerce")

        # לעשות סכום של עמודה  "Tei_sum"
        dftei["Tei_sum"] = dftei[Tei_questions].sum(axis=1)

        # לעשות תוצאה 
        result_tei = dftei[["participant_id", "Tei_sum"]]
        
        # להחזיר ממוצע of "Tei_sum"
        return result_tei, dftei["Tei_sum"].mean()
    
    except Exception as e:
        print(f"Error processing TEI scores: {e}")
        return None, None


def group_tei_by_score(dftei):
    try:
        # לייצר  "Group" שמתבססים "Tei_sum" value
        dftei["Group"] = dftei["Tei_sum"].apply(
            lambda x: "Non-Clinical" if x >= 128 else "Clinical"
        )
        
        grouped_tei = dftei.groupby("Group")["Tei_sum"].agg(["count", "mean", "median", "std"])
        
        # יצירת עמודה הסופית
        Tei_table = dftei[["participant_id", "Group", "Tei_sum"]]
        
        return grouped_tei, Tei_table
    
    except Exception as e:
        print(f"Error processing TEI grouping: {e}")
        return None, None

#DISPLAY THE RESULTS FOR TESTING THEM 

def merge_dataframes(*dfs):
    
    # יצירת רשימה 
    cleaned_dfs = []
    
    # בודק אם participant_id נמצא בכל עמודה 
    for i, df in enumerate(dfs, start=1): #עובר אחד אחד 
        missing_columns = []
        if "participant_id" not in df.columns:
            missing_columns.append("participant_id")
        if "Group" not in df.columns:
            missing_columns.append("Group")
        
        if missing_columns:
            print(f"Warning: Missing columns {', '.join(missing_columns)} in df{i}. Skipping this dataframe.")
            continue  #אם יש עמודות חסרות, לדלג 
        
        #להוריד עמודות שהן אותו דבר 
        df = df.loc[:, ~df.columns.duplicated()] #להפוך true לfalse ולהיפך, כדי מנוע כלפילויות 
        
        # אינדקס עבור עמודות
        df = df.set_index(["participant_id", "Group"])
        
        cleaned_dfs.append(df)
        
        
        print(f"df{i}:")
        print(f"Columns: {list(df.columns)}")
        print(f"Index: {list(df.index)}")
    
    #חיבור בין דאטה פריימים עבור העמודות הרלוונטיות לנו שהציון שלהן הוא 1 
    merged_df = pd.concat(cleaned_dfs, axis=1, keys=["AQ", "Altman", "Aadis", "Bdi", "Bpaq", "Ctqsf", "Dudit", "Pnr", 
                                                   "Pvss", "Quic", "Rse", "Susd", "Seq", "Teps", "Tei"])
    
    merged_df = merged_df.reset_index()
    
    return merged_df

#קריאת פונקציה 
merged_df = merge_dataframes(dfaq, dfmania, dfaadis, dfbpaq, dfbdi, dfctqsf, dfdudit, dfpnr, dfpvss, dfquic, dfrse, dfsusd, dfseq, dfteps, dftei)
print(merged_df) 



def classify_participants_by_clinical_occurrences(merged_df, clinical_value=1):
    def count_clinical_occurrences(df, clinical_value=1): #חישוב פונקצית עזר שרואה שיש קבוצות קליניות 
        return (df == clinical_value).sum(axis=1)

    #לשייך קבוצות קליניות עבור העמודה הרלוונטיתת 
    clinical_counts = count_clinical_occurrences(merged_df.iloc[:, 2:])  #בוחרים את כל העמודות מאינדקס 2 ומעל 

    # חישוב ממוצע 
    mean_clinical_count = clinical_counts.mean()

    # Classify participants based on the mean clinical count
    merged_df["clinical_classification"] = clinical_counts.apply(
        lambda x: "clinical" if x > mean_clinical_count else "non-clinical"
    )
    
    # הדאטה פריים אחרי ניקוי וחישובים 
    merged_df_filtered = merged_df[["participant_id", "Group"]]
    merged_df_filtered = merged_df_filtered.sort_values("participant_id").reset_index(drop=True)

    # לחלק את כל הדאטה פריים של כל העמודות ושאלונים לקליני ולא קליני 
    group_merge_df = merged_df_filtered["Group"]
    group_merge_df_encoded = group_merge_df.replace({"Clinical": 2, "Non-Clinical": 1})

    
    pd.set_option("future.no_silent_downcasting", True) #אם מספרים גדולים מדי זה יראה לנו שגיאה, כדי שלא יהיו ערכים לא צפויים
    #מאבד בדיוק אבל חוסך בזיכון (כי דאטה פריים גדול מאוד) 
    return merged_df, clinical_counts, merged_df_filtered, group_merge_df_encoded




def process_and_encode_groups(dfmania, dfctqsf): #זה רק בשביל ניסיון שלנו - לא השתמשנו בזה בסוף 
    
    # לקחת רק את שתי העמודות הבאות 
    dfmania_filtered = dfmania[["participant_id", "Group"]]
    dfctqsf_filtered = dfctqsf[["participant_id", "Group"]]
    
    # לחלק אותם לפי האינדקס
    dfmania_filtered = dfmania_filtered.sort_values("participant_id").reset_index(drop=True)
    dfctqsf_filtered = dfctqsf_filtered.sort_values("participant_id").reset_index(drop=True)
    
    # לוודא שיש התאמה 
    if not dfmania_filtered["participant_id"].equals(dfctqsf_filtered["participant_id"]):
        raise ValueError("Subject IDs do not match.") #מחלק לשתי עמודות שונות לניתוחים עתידיים 
    
    #מגדיר משתנים קליני ולא קליני במקום 
    group_mania_encoded = dfmania_filtered["Group"].replace({"Clinical": 2, "Non-Clinical": 1})
    group_ctqsf_encoded = dfctqsf_filtered["Group"].replace({"Clinical": 2, "Non-Clinical": 1})
    
    # דאטה פריים חדש 
    group_merge_df_encoded = pd.DataFrame({
        'participant_id': dfmania_filtered["participant_id"],
        'group_mania_encoded': group_mania_encoded,
        'group_ctqsf_encoded': group_ctqsf_encoded
    })
    
    return group_merge_df_encoded


from scipy.stats import ttest_ind
def generate_reward_stats_and_perform_ttest(group_merge_df_encoded):
    # יצירת סטטיסטיקות תגמול חברתיות וסטטיסטיקות תגמול פיננסי
    social_reward_stats = np.random.normal(loc=0.01698834814117839, scale=0.0013305286452984042, size=59)
    financial_reward_stats = np.random.normal(loc=1.0119452121411763, scale=0.00048389448197189383, size=59)
    
    # הצגת סוגי הנתונים
    print("Data Type of group_merge_df_encoded:", group_merge_df_encoded.dtype)
    print("Data Type of social_reward_stats:", social_reward_stats.dtype)
    
    # הצגת שם DataFrame
    print("Name of the DataFrame:", getattr(group_merge_df_encoded, 'name', 'No name attribute'))
    
    # המרת group_merge_df_encoded ל- numeric, עם טיפול בשגיאות
    group_merge_df_encoded = pd.to_numeric(group_merge_df_encoded, errors="coerce")
    
    # חישוב T-test בין group_merge_df_encoded ל-social_reward_stats
    t_stat_social, p_value_social = ttest_ind(group_merge_df_encoded, social_reward_stats)
    
    # הצגת תוצאות ה-T-test עבור תגמול חברתי
    print(f"Social Reward - T-statistic: {t_stat_social:.2f}, P-value: {p_value_social:.4f}")
    
    # בדיקת מובהקות עבור תגמול חברתי
    alpha = 0.05
    if p_value_social < alpha:
        print("The difference is statistically significant for social reward.")
    else:
        print("The difference is not statistically significant for social reward.")
    
    # חישוב T-test בין group_merge_df_encoded ל-financial_reward_stats
    t_stat_financial, p_value_financial = ttest_ind(group_merge_df_encoded, financial_reward_stats)
    
    # הצגת תוצאות ה-T-test עבור תגמול פיננסי
    print(f"Financial Reward - T-statistic: {t_stat_financial:.2f}, P-value: {p_value_financial:.4f}")
    
    # בדיקת מובהקות עבור תגמול פיננסי
    if p_value_financial < alpha:
        print("The difference is statistically significant for financial reward.")
    else:
        print("The difference is not statistically significant for financial reward.")
    
    # הצגת אורכים של הקבוצות
    print("Length of group_merge_df_encoded:", len(group_merge_df_encoded))
    print("Length of social_reward_stats:", len(social_reward_stats))
    
    # חיתוך group_merge_df_encoded כך שיתאים לאורך של social_reward_stats
    group_merge_df_encoded = group_merge_df_encoded[:len(social_reward_stats)]
    
    # יצירת DataFrame עם המשתנים שברצונך לחשב את המתאם ביניהם
    df = pd.DataFrame({
        "Clinical class": group_merge_df_encoded,
        "Social reward": social_reward_stats
    })
    
    # חישוב מטריצת המתאם
    correlation_matrix = df.corr()
    
    # הצגת מטריצת המתאם
    print("\nCorrelation Matrix:")
    print(correlation_matrix)
  
    # החזרת התוצאות
    return social_reward_stats, financial_reward_stats, group_merge_df_encoded, t_stat_social, p_value_social, t_stat_financial, p_value_financial, correlation_matrix
